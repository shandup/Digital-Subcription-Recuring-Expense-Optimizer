// API Base URL
const API_BASE = '/api';

// Dark Mode Management
function initDarkMode() {
    const isDarkMode = localStorage.getItem('darkMode') === 'true';
    if (isDarkMode) {
        document.documentElement.classList.add('dark');
    }
    updateDarkModeToggle();
}

function toggleDarkMode() {
    const isDarkMode = document.documentElement.classList.toggle('dark');
    localStorage.setItem('darkMode', isDarkMode);
    updateDarkModeToggle();
}

function updateDarkModeToggle() {
    const toggle = document.getElementById('toggleIndicator');
    if (toggle) {
        const isDarkMode = document.documentElement.classList.contains('dark');
        toggle.textContent = isDarkMode ? '☀️' : '🌙';
        toggle.style.transform = isDarkMode ? 'translateX(1.75rem)' : 'translateX(0)';
    }
}

// Authentication
function getToken() {
    return localStorage.getItem('token');
}

function getUser() {
    const userStr = localStorage.getItem('user');
    return userStr ? JSON.parse(userStr) : null;
}

function setToken(token) {
    localStorage.setItem('token', token);
}

function setUser(user) {
    localStorage.setItem('user', JSON.stringify(user));
}

function clearAuth() {
    localStorage.removeItem('token');
    localStorage.removeItem('user');
}

function checkAuth() {
    const token = getToken();
    if (!token) {
        window.location.href = 'login.html';
        return false;
    }
    return true;
}

// API Calls
async function apiCall(endpoint, options = {}) {
    const token = getToken();
    const headers = {
        'Content-Type': 'application/json',
        ...options.headers
    };

    if (token) {
        headers['Authorization'] = `Bearer ${token}`;
    }

    const response = await fetch(`${API_BASE}${endpoint}`, {
        ...options,
        headers
    });

    if (!response.ok) {
        const error = await response.json();
        throw new Error(error.error || 'API request failed');
    }

    return response.json();
}

// Update User Display
function renderAvatar(user) {
    const userAvatar = document.getElementById('userAvatar');
    if (!userAvatar) return;
    if (user.photo) {
        userAvatar.innerHTML = `<img src="${user.photo}" alt="Profile" class="w-full h-full object-cover rounded-full">`;
    } else {
        userAvatar.textContent = (user.name || 'U').charAt(0).toUpperCase();
    }
}

function updateUserDisplay() {
    const user = getUser();
    if (!user) return;

    const userName = document.getElementById('userName');
    if (userName) userName.textContent = user.name;
    renderAvatar(user);

    // Refresh name/photo from server
    apiCall('/auth/profile')
        .then(profile => {
            const updated = { id: profile.id, name: profile.name, email: profile.email, photo: profile.photo };
            setUser(updated);
            const nameEl = document.getElementById('userName');
            if (nameEl) nameEl.textContent = updated.name;
            renderAvatar(updated);
        })
        .catch(() => {});
}

// Account Dropdown & Profile Modals
function initAccountMenu() {
    const dropdown = document.getElementById('accountDropdown');
    if (!dropdown) return;

    const btn = document.getElementById('accountBtn');
    const menu = document.getElementById('accountMenu');

    btn.addEventListener('click', (e) => {
        e.stopPropagation();
        menu.classList.toggle('hidden');
    });

    document.addEventListener('click', (e) => {
        if (!dropdown.contains(e.target)) {
            menu.classList.add('hidden');
        }
    });

    document.getElementById('menuEditProfile').addEventListener('click', () => {
        menu.classList.add('hidden');
        openProfileModal();
    });
    document.getElementById('menuPhoto').addEventListener('click', () => {
        menu.classList.add('hidden');
        openPhotoModal();
    });
    document.getElementById('menuPassword').addEventListener('click', () => {
        menu.classList.add('hidden');
        openPasswordModal();
    });

    injectModals();
}

function injectModals() {
    if (document.getElementById('accountModals')) return;

    const container = document.createElement('div');
    container.id = 'accountModals';
    container.innerHTML = `
        <!-- Edit Profile Modal -->
        <div id="profileModal" class="hidden fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
            <div class="bg-white dark:bg-gray-800 rounded-lg shadow-lg p-6 w-full max-w-md mx-4">
                <h3 class="text-xl font-bold mb-4 text-gray-900 dark:text-white">✏️ Edit Account Details</h3>
                <div class="mb-4">
                    <label class="block text-gray-700 dark:text-gray-300 text-sm font-bold mb-2">Name</label>
                    <input type="text" id="profileName" class="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md bg-white dark:bg-gray-700 text-gray-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500">
                </div>
                <div class="mb-4">
                    <label class="block text-gray-700 dark:text-gray-300 text-sm font-bold mb-2">Email</label>
                    <input type="email" id="profileEmail" disabled class="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md bg-gray-100 dark:bg-gray-600 text-gray-500 dark:text-gray-300">
                </div>
                <div class="flex justify-end space-x-3">
                    <button type="button" id="cancelProfile" class="px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-md hover:bg-gray-50 dark:hover:bg-gray-700 text-gray-700 dark:text-gray-200">Cancel</button>
                    <button type="button" id="saveProfile" class="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700">Save</button>
                </div>
            </div>
        </div>

        <!-- Profile Photo Modal -->
        <div id="photoModal" class="hidden fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
            <div class="bg-white dark:bg-gray-800 rounded-lg shadow-lg p-6 w-full max-w-md mx-4">
                <h3 class="text-xl font-bold mb-4 text-gray-900 dark:text-white">🖼️ Add Profile Photo</h3>
                <div class="mb-4 flex justify-center">
                    <div id="photoPreview" class="w-24 h-24 rounded-full bg-gray-200 dark:bg-gray-600 flex items-center justify-center overflow-hidden">
                        <span class="text-3xl">👤</span>
                    </div>
                </div>
                <div class="mb-4">
                    <input type="file" id="photoInput" accept="image/*" class="w-full text-sm text-gray-600 dark:text-gray-300 file:mr-4 file:py-2 file:px-4 file:rounded-md file:border-0 file:bg-blue-600 file:text-white hover:file:bg-blue-700">
                </div>
                <div class="flex justify-end space-x-3">
                    <button type="button" id="cancelPhoto" class="px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-md hover:bg-gray-50 dark:hover:bg-gray-700 text-gray-700 dark:text-gray-200">Cancel</button>
                    <button type="button" id="savePhoto" class="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700">Save Photo</button>
                </div>
            </div>
        </div>

        <!-- Update Password Modal -->
        <div id="passwordModal" class="hidden fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
            <div class="bg-white dark:bg-gray-800 rounded-lg shadow-lg p-6 w-full max-w-md mx-4">
                <h3 class="text-xl font-bold mb-4 text-gray-900 dark:text-white">🔒 Update Password</h3>
                <div class="mb-4">
                    <label class="block text-gray-700 dark:text-gray-300 text-sm font-bold mb-2">Current Password</label>
                    <div class="relative">
                        <input type="password" id="currentPassword" class="w-full px-3 py-2 pr-10 border border-gray-300 dark:border-gray-600 rounded-md bg-white dark:bg-gray-700 text-gray-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500">
                        <button type="button" class="password-toggle absolute inset-y-0 right-0 px-3 flex items-center text-gray-500 hover:text-gray-700" data-target="currentPassword">
                            <svg class="eye-icon w-5 h-5" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M2 12s3-7 10-7 10 7 10 7-3 7-10 7-10-7-10-7Z"/><circle cx="12" cy="12" r="3"/></svg>
                            <svg class="eye-off-icon w-5 h-5 hidden" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M9.88 9.88a3 3 0 1 0 4.24 4.24"/><path d="M10.73 5.08A10.43 10.43 0 0 1 12 5c7 0 10 7 10 7a13.16 13.16 0 0 1-1.67 2.68"/><path d="M6.61 6.61A13.526 13.526 0 0 0 2 12s3 7 10 7c.41 0 .82-.02 1.23-.06"/><line x1="2" x2="22" y1="2" y2="22"/></svg>
                        </button>
                    </div>
                </div>
                <div class="mb-4">
                    <label class="block text-gray-700 dark:text-gray-300 text-sm font-bold mb-2">New Password</label>
                    <div class="relative">
                        <input type="password" id="newPassword" class="w-full px-3 py-2 pr-10 border border-gray-300 dark:border-gray-600 rounded-md bg-white dark:bg-gray-700 text-gray-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500">
                        <button type="button" class="password-toggle absolute inset-y-0 right-0 px-3 flex items-center text-gray-500 hover:text-gray-700" data-target="newPassword">
                            <svg class="eye-icon w-5 h-5" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M2 12s3-7 10-7 10 7 10 7-3 7-10 7-10-7-10-7Z"/><circle cx="12" cy="12" r="3"/></svg>
                            <svg class="eye-off-icon w-5 h-5 hidden" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M9.88 9.88a3 3 0 1 0 4.24 4.24"/><path d="M10.73 5.08A10.43 10.43 0 0 1 12 5c7 0 10 7 10 7a13.16 13.16 0 0 1-1.67 2.68"/><path d="M6.61 6.61A13.526 13.526 0 0 0 2 12s3 7 10 7c.41 0 .82-.02 1.23-.06"/><line x1="2" x2="22" y1="2" y2="22"/></svg>
                        </button>
                    </div>
                </div>
                <div class="mb-4">
                    <label class="block text-gray-700 dark:text-gray-300 text-sm font-bold mb-2">Confirm New Password</label>
                    <div class="relative">
                        <input type="password" id="confirmNewPassword" class="w-full px-3 py-2 pr-10 border border-gray-300 dark:border-gray-600 rounded-md bg-white dark:bg-gray-700 text-gray-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500">
                        <button type="button" class="password-toggle absolute inset-y-0 right-0 px-3 flex items-center text-gray-500 hover:text-gray-700" data-target="confirmNewPassword">
                            <svg class="eye-icon w-5 h-5" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M2 12s3-7 10-7 10 7 10 7-3 7-10 7-10-7-10-7Z"/><circle cx="12" cy="12" r="3"/></svg>
                            <svg class="eye-off-icon w-5 h-5 hidden" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M9.88 9.88a3 3 0 1 0 4.24 4.24"/><path d="M10.73 5.08A10.43 10.43 0 0 1 12 5c7 0 10 7 10 7a13.16 13.16 0 0 1-1.67 2.68"/><path d="M6.61 6.61A13.526 13.526 0 0 0 2 12s3 7 10 7c.41 0 .82-.02 1.23-.06"/><line x1="2" x2="22" y1="2" y2="22"/></svg>
                        </button>
                    </div>
                </div>
                <div class="flex justify-end space-x-3">
                    <button type="button" id="cancelPassword" class="px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-md hover:bg-gray-50 dark:hover:bg-gray-700 text-gray-700 dark:text-gray-200">Cancel</button>
                    <button type="button" id="savePassword" class="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700">Update</button>
                </div>
            </div>
        </div>
    `;
    document.body.appendChild(container);

    // Profile modal handlers
    document.getElementById('cancelProfile').addEventListener('click', () => {
        document.getElementById('profileModal').classList.add('hidden');
    });
    document.getElementById('saveProfile').addEventListener('click', async () => {
        const name = document.getElementById('profileName').value.trim();
        if (!name) {
            alert('Name cannot be empty');
            return;
        }
        try {
            const res = await apiCall('/auth/profile', {
                method: 'PUT',
                body: JSON.stringify({ name })
            });
            const user = getUser() || {};
            setUser({ ...user, name: res.user.name, email: res.user.email, photo: res.user.photo });
            updateUserDisplay();
            document.getElementById('profileModal').classList.add('hidden');
            alert('Profile updated successfully');
        } catch (error) {
            alert(error.message);
        }
    });

    // Photo modal handlers
    let pendingPhoto = null;
    document.getElementById('photoInput').addEventListener('change', (e) => {
        const file = e.target.files[0];
        if (!file) return;
        if (file.size > 1.5 * 1024 * 1024) {
            alert('Image is too large (max ~1.5 MB)');
            e.target.value = '';
            return;
        }
        const reader = new FileReader();
        reader.onload = (ev) => {
            pendingPhoto = ev.target.result;
            document.getElementById('photoPreview').innerHTML = `<img src="${pendingPhoto}" alt="Preview" class="w-full h-full object-cover">`;
        };
        reader.readAsDataURL(file);
    });
    document.getElementById('cancelPhoto').addEventListener('click', () => {
        document.getElementById('photoModal').classList.add('hidden');
        document.getElementById('photoInput').value = '';
        pendingPhoto = null;
    });
    document.getElementById('savePhoto').addEventListener('click', async () => {
        if (!pendingPhoto) {
            alert('Please choose an image first');
            return;
        }
        try {
            await apiCall('/auth/photo', {
                method: 'PUT',
                body: JSON.stringify({ photo: pendingPhoto })
            });
            const user = getUser() || {};
            setUser({ ...user, photo: pendingPhoto });
            updateUserDisplay();
            document.getElementById('photoModal').classList.add('hidden');
            document.getElementById('photoInput').value = '';
            pendingPhoto = null;
            alert('Profile photo updated successfully');
        } catch (error) {
            alert(error.message);
        }
    });

    // Password modal handlers
    document.getElementById('cancelPassword').addEventListener('click', () => {
        document.getElementById('passwordModal').classList.add('hidden');
    });
    document.getElementById('savePassword').addEventListener('click', async () => {
        const currentPassword = document.getElementById('currentPassword').value;
        const newPassword = document.getElementById('newPassword').value;
        const confirmNewPassword = document.getElementById('confirmNewPassword').value;

        if (newPassword !== confirmNewPassword) {
            alert('New passwords do not match');
            return;
        }
        if (newPassword.length < 6) {
            alert('New password must be at least 6 characters');
            return;
        }

        try {
            await apiCall('/auth/password', {
                method: 'PUT',
                body: JSON.stringify({ currentPassword, newPassword })
            });
            document.getElementById('passwordModal').classList.add('hidden');
            document.getElementById('currentPassword').value = '';
            document.getElementById('newPassword').value = '';
            document.getElementById('confirmNewPassword').value = '';
            alert('Password updated successfully');
        } catch (error) {
            alert(error.message);
        }
    });
}

function openProfileModal() {
    const user = getUser();
    document.getElementById('profileName').value = user ? user.name : '';
    document.getElementById('profileEmail').value = user ? user.email : '';
    document.getElementById('profileModal').classList.remove('hidden');
}

function openPhotoModal() {
    const user = getUser();
    const preview = document.getElementById('photoPreview');
    preview.innerHTML = user && user.photo
        ? `<img src="${user.photo}" alt="Current" class="w-full h-full object-cover">`
        : '<span class="text-3xl">👤</span>';
    document.getElementById('photoModal').classList.remove('hidden');
}

function openPasswordModal() {
    document.getElementById('passwordModal').classList.remove('hidden');
}

// Show Error
function showError(message) {
    const errorDiv = document.getElementById('error');
    const errorMessage = document.getElementById('errorMessage');
    if (errorDiv) {
        errorDiv.classList.remove('hidden');
        if (errorMessage) {
            errorMessage.textContent = message;
        } else {
            errorDiv.textContent = message;
        }
    }
}

// Hide Error
function hideError() {
    const errorDiv = document.getElementById('error');
    if (errorDiv) {
        errorDiv.classList.add('hidden');
    }
}

// Login Handler
function handleLogin() {
    const form = document.getElementById('loginForm');
    if (!form) return;

    form.addEventListener('submit', async (e) => {
        e.preventDefault();
        hideError();

        const email = document.getElementById('email').value;
        const password = document.getElementById('password').value;

        try {
            const response = await apiCall('/auth/login', {
                method: 'POST',
                body: JSON.stringify({ email, password })
            });

            setToken(response.token);
            setUser(response.user);
            window.location.href = 'dashboard.html';
        } catch (error) {
            showError(error.message);
        }
    });
}

// Register Handler
function handleRegister() {
    const form = document.getElementById('registerForm');
    if (!form) return;

    form.addEventListener('submit', async (e) => {
        e.preventDefault();
        hideError();

        const name = document.getElementById('name').value;
        const email = document.getElementById('email').value;
        const password = document.getElementById('password').value;
        const confirmPassword = document.getElementById('confirmPassword').value;

        if (password !== confirmPassword) {
            showError('Passwords do not match');
            return;
        }

        if (password.length < 6) {
            showError('Password must be at least 6 characters');
            return;
        }

        try {
            const response = await apiCall('/auth/register', {
                method: 'POST',
                body: JSON.stringify({ name, email, password })
            });

            setToken(response.token);
            setUser(response.user);
            window.location.href = 'dashboard.html';
        } catch (error) {
            showError(error.message);
        }
    });
}

// Logout Handler
function handleLogout() {
    const logoutBtn = document.getElementById('logoutBtn');
    if (logoutBtn) {
        logoutBtn.addEventListener('click', () => {
            clearAuth();
            window.location.href = 'login.html';
        });
    }
}

// Dashboard Page
function initDashboard() {
    if (!checkAuth()) return;

    apiCall('/analytics/dashboard')
        .then(data => {
            document.getElementById('totalCost').textContent = `₹${parseFloat(data.totalMonthlyCost).toFixed(2)}`;
            document.getElementById('activeCount').textContent = data.statusCounts.Active || 0;
            document.getElementById('upcomingCount').textContent = data.upcomingRenewals.length;
            document.getElementById('activeStatus').textContent = data.statusCounts.Active || 0;
            document.getElementById('pausedStatus').textContent = data.statusCounts.Paused || 0;
            document.getElementById('cancelledStatus').textContent = data.statusCounts.Cancelled || 0;

            // Upcoming Renewals
            const upcomingContent = document.getElementById('upcomingRenewalsContent');
            if (data.upcomingRenewals.length > 0) {
                upcomingContent.innerHTML = `
                    <div class="overflow-x-auto">
                        <table class="min-w-full">
                            <thead>
                                <tr class="border-b-2 border-gray-200 dark:border-gray-600 bg-gray-50 dark:bg-gray-700">
                                    <th class="text-left py-3 px-4 font-semibold text-gray-700 dark:text-gray-300">Platform</th>
                                    <th class="text-left py-3 px-4 font-semibold text-gray-700 dark:text-gray-300">Cost</th>
                                    <th class="text-left py-3 px-4 font-semibold text-gray-700 dark:text-gray-300">Renewal Date</th>
                                </tr>
                            </thead>
                            <tbody>
                                ${data.upcomingRenewals.map(renewal => `
                                    <tr class="border-b border-gray-200 dark:border-gray-600 hover:bg-blue-50 dark:hover:bg-gray-700 transition">
                                        <td class="py-3 px-4 font-medium text-gray-900 dark:text-white">${renewal.PlatformName}</td>
                                        <td class="py-3 px-4 font-semibold text-blue-600">₹${parseFloat(renewal.Cost).toFixed(2)}</td>
                                        <td class="py-3 px-4 text-gray-900 dark:text-white">${new Date(renewal.NextRenewalDate).toLocaleDateString()}</td>
                                    </tr>
                                `).join('')}
                            </tbody>
                        </table>
                    </div>
                `;
            }

            // Recent Usage
            const recentUsageContent = document.getElementById('recentUsageContent');
            if (data.recentUsage.length > 0) {
                recentUsageContent.innerHTML = `
                    <div class="overflow-x-auto">
                        <table class="min-w-full">
                            <thead>
                                <tr class="border-b-2 border-gray-200 dark:border-gray-600 bg-gray-50 dark:bg-gray-700">
                                    <th class="text-left py-3 px-4 font-semibold text-gray-700 dark:text-gray-300">Platform</th>
                                    <th class="text-left py-3 px-4 font-semibold text-gray-700 dark:text-gray-300">Date</th>
                                    <th class="text-left py-3 px-4 font-semibold text-gray-700 dark:text-gray-300">Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                ${data.recentUsage.map(usage => `
                                    <tr class="border-b border-gray-200 dark:border-gray-600 hover:bg-blue-50 dark:hover:bg-gray-700 transition">
                                        <td class="py-3 px-4 font-medium text-gray-900 dark:text-white">${usage.PlatformName}</td>
                                        <td class="py-3 px-4 text-gray-900 dark:text-white">${new Date(usage.DateAccessed).toLocaleDateString()}</td>
                                        <td class="py-3 px-4">
                                            <span class="bg-blue-100 dark:bg-blue-900/30 text-blue-800 dark:text-blue-300 px-2 py-1 rounded-full text-sm">
                                                ${usage.ActionType}
                                            </span>
                                        </td>
                                    </tr>
                                `).join('')}
                            </tbody>
                        </table>
                    </div>
                `;
            }
        })
        .catch(error => {
            console.error('Error loading dashboard:', error);
        });
}

// Dashboard card interactions
function initDashboardCards() {
    const costCard = document.getElementById('costCard');
    const activeCard = document.getElementById('activeCard');
    const upcomingCard = document.getElementById('upcomingCard');

    if (activeCard) {
        activeCard.addEventListener('click', () => {
            document.getElementById('statusSection')?.scrollIntoView({ behavior: 'smooth' });
        });
    }
    if (upcomingCard) {
        upcomingCard.addEventListener('click', () => {
            document.getElementById('renewalsSection')?.scrollIntoView({ behavior: 'smooth' });
        });
    }
    if (costCard) {
        costCard.addEventListener('click', openCostBreakdown);
    }
}

function monthlyCost(sub) {
    const cost = parseFloat(sub.Cost) || 0;
    switch (sub.BillingCycle) {
        case 'Monthly': return cost;
        case 'Quarterly': return cost / 3;
        case 'Annual': return cost / 12;
        default: return cost;
    }
}

function openCostBreakdown() {
    if (!document.getElementById('costBreakdownModal')) {
        const modal = document.createElement('div');
        modal.id = 'costBreakdownModal';
        modal.className = 'hidden fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50';
        modal.innerHTML = `
            <div class="bg-white dark:bg-gray-800 rounded-lg shadow-lg p-6 w-full max-w-2xl mx-4 max-h-[80vh] flex flex-col">
                <div class="flex justify-between items-center mb-4">
                    <h3 class="text-xl font-bold text-gray-900 dark:text-white">💰 Monthly Cost Breakdown</h3>
                    <button type="button" id="closeCostModal" class="text-gray-500 hover:text-gray-700 dark:hover:text-gray-300 text-2xl leading-none">&times;</button>
                </div>
                <div id="costBreakdownBody" class="overflow-y-auto"></div>
            </div>
        `;
        document.body.appendChild(modal);
        document.getElementById('closeCostModal').addEventListener('click', () => {
            modal.classList.add('hidden');
        });
        modal.addEventListener('click', (e) => {
            if (e.target === modal) modal.classList.add('hidden');
        });
    }

    const modal = document.getElementById('costBreakdownModal');
    const body = document.getElementById('costBreakdownBody');
    body.innerHTML = '<p class="text-center text-gray-500 py-8">Loading...</p>';
    modal.classList.remove('hidden');

    apiCall('/subscriptions')
        .then(subs => {
            const active = subs.filter(s => s.Status === 'Active');
            if (active.length === 0) {
                body.innerHTML = '<p class="text-center text-gray-500 dark:text-gray-400 py-8">No active subscriptions</p>';
                return;
            }
            const total = active.reduce((sum, s) => sum + monthlyCost(s), 0);
            body.innerHTML = `
                <table class="min-w-full">
                    <thead>
                        <tr class="border-b-2 border-gray-200 dark:border-gray-600">
                            <th class="text-left py-2 px-3 font-semibold text-gray-700 dark:text-gray-300">Platform</th>
                            <th class="text-left py-2 px-3 font-semibold text-gray-700 dark:text-gray-300">Plan</th>
                            <th class="text-left py-2 px-3 font-semibold text-gray-700 dark:text-gray-300">Cycle</th>
                            <th class="text-right py-2 px-3 font-semibold text-gray-700 dark:text-gray-300">Monthly Cost</th>
                        </tr>
                    </thead>
                    <tbody>
                        ${active.map(s => `
                            <tr class="border-b border-gray-200 dark:border-gray-600">
                                <td class="py-2 px-3 font-medium text-gray-900 dark:text-white">${s.PlatformName}</td>
                                <td class="py-2 px-3 text-gray-600 dark:text-gray-300">${s.PlanName || '-'}</td>
                                <td class="py-2 px-3 text-gray-600 dark:text-gray-300">${s.BillingCycle}</td>
                                <td class="py-2 px-3 text-right font-semibold text-blue-600">₹${monthlyCost(s).toFixed(2)}</td>
                            </tr>
                        `).join('')}
                    </tbody>
                    <tfoot>
                        <tr class="border-t-2 border-gray-300 dark:border-gray-500">
                            <td colspan="3" class="py-3 px-3 font-bold text-gray-900 dark:text-white text-right">Total</td>
                            <td class="py-3 px-3 text-right font-bold text-blue-600 text-lg">₹${total.toFixed(2)}</td>
                        </tr>
                    </tfoot>
                </table>
            `;
        })
        .catch(error => {
            console.error('Error loading cost breakdown:', error);
            body.innerHTML = '<p class="text-center text-red-500 py-8">Failed to load breakdown</p>';
        });
}

// Subscriptions Page
function initSubscriptions() {
    if (!checkAuth()) return;

    let subscriptionToDelete = null;

    apiCall('/subscriptions')
        .then(subscriptions => {
            const content = document.getElementById('subscriptionsContent');
            if (subscriptions.length === 0) {
                content.innerHTML = `
                    <div class="bg-white dark:bg-gray-800 rounded-lg shadow-lg p-12 text-center">
                        <span class="text-6xl mb-4 block">📭</span>
                        <h2 class="text-2xl font-bold text-gray-700 dark:text-gray-300 mb-2">No Subscriptions Yet</h2>
                        <p class="text-gray-500 dark:text-gray-400 mb-6">Start tracking your subscriptions to manage your expenses better</p>
                        <a href="subscription-form.html" class="bg-gradient-to-r from-blue-500 to-blue-600 text-white px-6 py-3 rounded-lg hover:from-blue-600 hover:to-blue-700 transition shadow-lg">
                            Add Your First Subscription
                        </a>
                    </div>
                `;
            } else {
                const getStatusColor = (status) => {
                    switch (status) {
                        case 'Active': return 'bg-green-100 text-green-800';
                        case 'Paused': return 'bg-yellow-100 text-yellow-800';
                        case 'Cancelled': return 'bg-red-100 text-red-800';
                        default: return 'bg-gray-100 text-gray-800';
                    }
                };

                content.innerHTML = `
                    <div class="bg-white dark:bg-gray-800 rounded-lg shadow-lg overflow-hidden">
                        <div class="overflow-x-auto">
                            <table class="min-w-full">
                                <thead class="bg-gradient-to-r from-gray-50 to-gray-100 dark:from-gray-700 dark:to-gray-800">
                                    <tr>
                                        <th class="text-left py-4 px-4 font-semibold text-gray-700 dark:text-gray-300">Platform</th>
                                        <th class="text-left py-4 px-4 font-semibold text-gray-700 dark:text-gray-300">Plan</th>
                                        <th class="text-left py-4 px-4 font-semibold text-gray-700 dark:text-gray-300">Cost</th>
                                        <th class="text-left py-4 px-4 font-semibold text-gray-700 dark:text-gray-300">Cycle</th>
                                        <th class="text-left py-4 px-4 font-semibold text-gray-700 dark:text-gray-300">Status</th>
                                        <th class="text-left py-4 px-4 font-semibold text-gray-700 dark:text-gray-300">Next Renewal</th>
                                        <th class="text-left py-4 px-4 font-semibold text-gray-700 dark:text-gray-300">Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    ${subscriptions.map(sub => `
                                        <tr class="border-b border-gray-200 dark:border-gray-600 hover:bg-blue-50 dark:hover:bg-gray-700 transition">
                                            <td class="py-4 px-4 font-medium">${sub.WebsiteURL ? `<a href="${sub.WebsiteURL}" target="_blank" class="text-blue-600 hover:underline">${sub.PlatformName} 🔗</a>` : sub.PlatformName}</td>
                                            <td class="py-4 px-4">${sub.PlanName || '-'}</td>
                                            <td class="py-4 px-4 font-semibold text-blue-600">₹${parseFloat(sub.Cost).toFixed(2)}</td>
                                            <td class="py-4 px-4">
                                                <span class="bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-300 px-2 py-1 rounded text-sm">
                                                    ${sub.BillingCycle}
                                                </span>
                                            </td>
                                            <td class="py-4 px-4">
                                                <span class="px-3 py-1 rounded-full text-xs font-semibold ${getStatusColor(sub.Status)}">
                                                    ${sub.Status}
                                                </span>
                                            </td>
                                            <td class="py-4 px-4">${new Date(sub.NextRenewalDate).toLocaleDateString()}</td>
                                            <td class="py-4 px-4">
                                                <div class="flex items-center space-x-2">
                                                    <button onclick="toggleAutoRenew(${sub.SubID}, ${sub.AutoRenew === null ? true : sub.AutoRenew})"
                                                        class="relative inline-flex h-6 w-11 items-center rounded-full transition ${sub.AutoRenew === null || sub.AutoRenew ? 'bg-blue-500' : 'bg-gray-400'}"
                                                        title="${sub.AutoRenew === null || sub.AutoRenew ? 'Auto-renewal enabled - click to disable' : 'Auto-renewal disabled - click to enable'}">
                                                        <span class="inline-block h-4 w-4 transform rounded-full bg-white shadow transition ${sub.AutoRenew === null || sub.AutoRenew ? 'translate-x-6' : 'translate-x-1'}"></span>
                                                    </button>
                                                    <span class="text-xs text-gray-500 dark:text-gray-400">Auto</span>
                                                    <button onclick="toggleSubscriptionStatus(${sub.SubID}, '${sub.Status}')"
                                                        class="relative inline-flex h-6 w-11 items-center rounded-full transition ${sub.Status === 'Active' ? 'bg-green-500' : sub.Status === 'Paused' ? 'bg-yellow-500' : 'bg-gray-400 cursor-not-allowed'}"
                                                        title="${sub.Status === 'Active' ? 'Active - click to pause' : sub.Status === 'Paused' ? 'Paused - click to activate' : 'Cancelled'}">
                                                        <span class="inline-block h-4 w-4 transform rounded-full bg-white shadow transition ${sub.Status === 'Active' ? 'translate-x-6' : 'translate-x-1'}"></span>
                                                    </button>
                                                    <a href="subscription-form.html?id=${sub.SubID}" class="text-blue-600 hover:text-blue-800 font-medium flex items-center">
                                                        <span class="mr-1">✏️</span> Edit
                                                    </a>
                                                    <button onclick="confirmDelete(${sub.SubID})" class="text-red-600 hover:text-red-800 font-medium flex items-center">
                                                        <span class="mr-1">🗑️</span> Delete
                                                    </button>
                                                </div>
                                            </td>
                                        </tr>
                                    `).join('')}
                                </tbody>
                            </table>
                        </div>
                    </div>
                `;
            }
        })
        .catch(error => {
            console.error('Error loading subscriptions:', error);
        });

    // Delete Modal
    window.confirmDelete = (subId) => {
        subscriptionToDelete = subId;
        document.getElementById('deleteModal').classList.remove('hidden');
    };

    window.toggleSubscriptionStatus = async (subId, currentStatus) => {
        if (currentStatus !== 'Active' && currentStatus !== 'Paused') return;
        const newStatus = currentStatus === 'Active' ? 'Paused' : 'Active';
        try {
            await apiCall(`/subscriptions/${subId}/status`, {
                method: 'PATCH',
                body: JSON.stringify({ status: newStatus })
            });
            initSubscriptions();
        } catch (error) {
            console.error('Error updating subscription status:', error);
            alert(error.message || 'Error updating subscription status');
        }
    };

    window.toggleAutoRenew = async (subId, currentAutoRenew) => {
        try {
            await apiCall(`/subscriptions/${subId}/auto-renew`, {
                method: 'PATCH',
                body: JSON.stringify({ autoRenew: !currentAutoRenew })
            });
            initSubscriptions();
        } catch (error) {
            console.error('Error toggling auto-renewal:', error);
            alert(error.message || 'Error toggling auto-renewal');
        }
    };

    document.getElementById('cancelDelete').addEventListener('click', () => {
        subscriptionToDelete = null;
        document.getElementById('deleteModal').classList.add('hidden');
    });

    document.getElementById('confirmDelete').addEventListener('click', async () => {
        if (subscriptionToDelete) {
            try {
                await apiCall(`/subscriptions/${subscriptionToDelete}`, { method: 'DELETE' });
                document.getElementById('deleteModal').classList.add('hidden');
                initSubscriptions();
            } catch (error) {
                alert('Error deleting subscription');
            }
        }
    });
}

// Subscription Form Page
function initSubscriptionForm() {
    if (!checkAuth()) return;

    const urlParams = new URLSearchParams(window.location.search);
    const subId = urlParams.get('id');
    const isEdit = !!subId;

    if (isEdit) {
        document.getElementById('formTitle').textContent = 'Edit Subscription';
        document.querySelector('button[type="submit"]').textContent = '💾 Update Subscription';
        document.getElementById('statusField').classList.remove('hidden');

        apiCall(`/subscriptions/${subId}`)
            .then(sub => {
                document.getElementById('subId').value = sub.SubID;
                document.getElementById('platformName').value = sub.PlatformName;
                document.getElementById('planName').value = sub.PlanName || '';
                document.getElementById('cost').value = sub.Cost;
                document.getElementById('billingCycle').value = sub.BillingCycle;
                document.getElementById('startDate').value = sub.StartDate.split('T')[0];
                document.getElementById('websiteUrl').value = sub.WebsiteURL || '';
                document.getElementById('status').value = sub.Status;
                document.getElementById('autoRenew').value = sub.AutoRenew === null ? 'true' : sub.AutoRenew ? 'true' : 'false';
                updateAutoRenewToggle();
            })
            .catch(error => {
                console.error('Error loading subscription:', error);
            });
    }

    function updateAutoRenewToggle() {
        const enabled = document.getElementById('autoRenew').value === 'true';
        const btn = document.getElementById('autoRenewToggle');
        const knob = btn.querySelector('span');
        btn.classList.toggle('bg-blue-500', enabled);
        btn.classList.toggle('bg-gray-400', !enabled);
        knob.classList.toggle('translate-x-6', enabled);
        knob.classList.toggle('translate-x-1', !enabled);
        btn.title = enabled ? 'Auto-renewal enabled - click to disable' : 'Auto-renewal disabled - click to enable';
    }

    document.getElementById('autoRenewToggle').addEventListener('click', () => {
        const current = document.getElementById('autoRenew').value === 'true';
        document.getElementById('autoRenew').value = current ? 'false' : 'true';
        updateAutoRenewToggle();
    });

    // Form submission
    document.getElementById('subscriptionForm').addEventListener('submit', async (e) => {
        e.preventDefault();
        hideError();

        const data = {
            platformName: document.getElementById('platformName').value,
            planName: document.getElementById('planName').value,
            cost: parseFloat(document.getElementById('cost').value),
            billingCycle: document.getElementById('billingCycle').value,
            startDate: document.getElementById('startDate').value,
            status: document.getElementById('status').value,
            websiteUrl: document.getElementById('websiteUrl').value,
            autoRenew: document.getElementById('autoRenew').value === 'true'
        };

        try {
            if (isEdit) {
                await apiCall(`/subscriptions/${subId}`, {
                    method: 'PUT',
                    body: JSON.stringify(data)
                });
            } else {
                await apiCall('/subscriptions', {
                    method: 'POST',
                    body: JSON.stringify(data)
                });
            }
            window.location.href = 'subscriptions.html';
        } catch (error) {
            showError(error.message);
        }
    });
}

// Analytics Page
function initAnalytics() {
    if (!checkAuth()) return;

    apiCall('/analytics/waste-report')
        .then(data => {
            const summary = {
                totalSubscriptions: data.length,
                highRiskCount: data.filter(item => item.WasteRecommendation.includes('High Risk')).length,
                totalMonthlyCost: data.reduce((sum, item) => {
                    const cost = parseFloat(item.Cost);
                    switch (item.BillingCycle) {
                        case 'Monthly': return sum + cost;
                        case 'Quarterly': return sum + cost / 3;
                        case 'Annual': return sum + cost / 12;
                        default: return sum;
                    }
                }, 0),
                potentialSavings: data
                    .filter(item => item.WasteRecommendation.includes('High Risk'))
                    .reduce((sum, item) => {
                        const cost = parseFloat(item.Cost);
                        switch (item.BillingCycle) {
                            case 'Monthly': return sum + cost;
                            case 'Quarterly': return sum + cost / 3;
                            case 'Annual': return sum + cost / 12;
                            default: return sum;
                        }
                    }, 0)
            };

            document.getElementById('totalSubs').textContent = summary.totalSubscriptions;
            document.getElementById('highRiskCount').textContent = summary.highRiskCount;
            document.getElementById('totalMonthlyCost').textContent = `₹${summary.totalMonthlyCost.toFixed(2)}`;
            document.getElementById('potentialSavings').textContent = `₹${summary.potentialSavings.toFixed(2)}`;
            document.getElementById('activeEngagement').textContent = summary.totalSubscriptions - summary.highRiskCount;
            document.getElementById('highRisk').textContent = summary.highRiskCount;

            // Insights
            document.getElementById('insight1').textContent = `You have ${summary.highRiskCount} high-risk subscription(s) that haven't been used in over 30 days.`;
            document.getElementById('insight2').textContent = `Cancelling high-risk subscriptions could save you approximately ₹${summary.potentialSavings.toFixed(2)} per month.`;
            document.getElementById('insight3').textContent = summary.highRiskCount > 0
                ? 'Review your high-risk subscriptions and consider downgrading or cancelling them.'
                : 'Great job! All your subscriptions are actively used.';

            // Table
            const tableContent = document.getElementById('analyticsTable');
            if (data.length > 0) {
                const getRecommendationColor = (recommendation) => {
                    return recommendation.includes('High Risk')
                        ? 'bg-red-100 text-red-800'
                        : 'bg-green-100 text-green-800';
                };

                tableContent.innerHTML = `
                    <div class="overflow-x-auto">
                        <table class="min-w-full">
                            <thead class="bg-gradient-to-r from-gray-50 to-gray-100 dark:from-gray-700 dark:to-gray-800">
                                <tr>
                                    <th class="text-left py-3 px-4 font-semibold text-gray-700 dark:text-gray-300">Platform</th>
                                    <th class="text-left py-3 px-4 font-semibold text-gray-700 dark:text-gray-300">Plan</th>
                                    <th class="text-left py-3 px-4 font-semibold text-gray-700 dark:text-gray-300">Cost</th>
                                    <th class="text-left py-3 px-4 font-semibold text-gray-700 dark:text-gray-300">Cycle</th>
                                    <th class="text-left py-3 px-4 font-semibold text-gray-700 dark:text-gray-300">Last Used</th>
                                    <th class="text-left py-3 px-4 font-semibold text-gray-700 dark:text-gray-300">Days Since Use</th>
                                    <th class="text-left py-3 px-4 font-semibold text-gray-700 dark:text-gray-300">Recommendation</th>
                                </tr>
                            </thead>
                            <tbody>
                                ${data.map(item => `
                                    <tr class="border-b border-gray-200 dark:border-gray-600 hover:bg-blue-50 dark:hover:bg-gray-700 transition">
                                        <td class="py-3 px-4 font-medium text-gray-900 dark:text-white">${item.PlatformName}</td>
                                        <td class="py-3 px-4 text-gray-900 dark:text-white">${item.PlanName || '-'}</td>
                                        <td class="py-3 px-4 font-semibold text-blue-600">₹${parseFloat(item.Cost).toFixed(2)}</td>
                                        <td class="py-3 px-4">
                                            <span class="bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-300 px-2 py-1 rounded text-sm">
                                                ${item.BillingCycle}
                                            </span>
                                        </td>
                                        <td class="py-3 px-4 text-gray-900 dark:text-white">
                                            ${item.LastUsedDate ? new Date(item.LastUsedDate).toLocaleDateString() : 'Never'}
                                        </td>
                                        <td class="py-3 px-4 font-semibold text-gray-900 dark:text-white">${item.DaysSinceLastUse}</td>
                                        <td class="py-3 px-4">
                                            <span class="px-3 py-1 rounded-full text-xs font-semibold ${getRecommendationColor(item.WasteRecommendation)}">
                                                ${item.WasteRecommendation}
                                            </span>
                                            ${item.WasteRecommendation.includes('High Risk') ? `
                                            <button onclick="paySubscription(${item.SubID}, '${item.PlatformName.replace(/'/g, "\\'")}')" class="ml-2 text-xs bg-green-600 text-white px-2 py-1 rounded hover:bg-green-700" title="Pay from wallet">
                                                💳 Pay
                                            </button>` : ''}
                                        </td>
                                    </tr>
                                `).join('')}
                            </tbody>
                        </table>
                    </div>
                `;
            }
        })
        .catch(error => {
            console.error('Error loading analytics:', error);
        });
}

// Payment Methods Page
function initPaymentMethods() {
    if (!checkAuth()) return;

    let isEditing = false;

    function updatePaymentFields() {
        const isUpi = document.getElementById('paymentType').value === 'upi';
        document.getElementById('cardNumberField').classList.toggle('hidden', isUpi);
        document.getElementById('upiIdField').classList.toggle('hidden', !isUpi);
        document.getElementById('expiryField').classList.toggle('hidden', isUpi);
        document.getElementById('cardNumber').required = !isUpi;
        document.getElementById('upiId').required = isUpi;
        document.getElementById('expiryDate').required = !isUpi;
    }

    document.getElementById('paymentType').addEventListener('change', updatePaymentFields);
    updatePaymentFields();

    function loadPaymentMethods() {
        apiCall('/payments')
            .then(methods => {
                const list = document.getElementById('paymentMethodsList');
                if (methods.length === 0) {
                    list.innerHTML = `
                        <div class="text-center py-8">
                            <span class="text-5xl mb-4 block">💳</span>
                            <p class="text-gray-500 dark:text-gray-400">No payment methods added yet</p>
                        </div>
                    `;
                } else {
                    list.innerHTML = methods.map(method => `
                        <div class="border-2 border-gray-200 dark:border-gray-600 rounded-lg p-6 hover:border-blue-300 dark:hover:border-blue-500 hover:bg-blue-50 dark:hover:bg-gray-700 transition mb-4">
                            <div class="flex justify-between items-start">
                                <div class="flex items-center">
                                    <span class="text-3xl mr-4">💳</span>
                                    <div>
                                        <h3 class="font-semibold text-lg text-gray-900 dark:text-white">${method.Provider}</h3>
                                        <p class="text-gray-600 dark:text-gray-300">
                                            ${method.PaymentType === 'upi' ? '📱 UPI' : method.PaymentType === 'debit_card' ? '🏧 Debit Card' : '💳 Credit Card'}
                                            ${method.PaymentType === 'upi' ? `- ${method.UPIID || ''}` : `- **** ${method.CardLast4}`}
                                        </p>
                                        ${method.PaymentType !== 'upi' ? `
                                        <p class="text-sm text-gray-500 dark:text-gray-400">
                                            Expires: ${method.ExpiryDate ? new Date(method.ExpiryDate).toLocaleDateString() : '-'}
                                        </p>` : ''}
                                    </div>
                                </div>
                                <div class="flex space-x-2">
                                    <button onclick="editPayment(${method.MethodID})" class="text-blue-600 hover:text-blue-800 font-medium flex items-center">
                                        <span class="mr-1">✏️</span> Edit
                                    </button>
                                    <button onclick="deletePayment(${method.MethodID})" class="text-red-600 hover:text-red-800 font-medium flex items-center">
                                        <span class="mr-1">🗑️</span> Delete
                                    </button>
                                </div>
                            </div>
                        </div>
                    `).join('');
                }
            })
            .catch(error => {
                console.error('Error loading payment methods:', error);
            });
    }

    window.editPayment = (methodId) => {
        apiCall(`/payments/${methodId}`)
            .then(method => {
                const type = method.PaymentType || 'credit_card';
                document.getElementById('editingId').value = method.MethodID;
                document.getElementById('paymentType').value = type;
                updatePaymentFields();
                document.getElementById('provider').value = method.Provider;
                if (type === 'upi') {
                    document.getElementById('upiId').value = method.UPIID || '';
                    document.getElementById('cardNumber').value = '';
                    document.getElementById('expiryDate').value = '';
                } else {
                    document.getElementById('cardNumber').value = '';
                    document.getElementById('upiId').value = '';
                    document.getElementById('expiryDate').value = method.ExpiryDate ? method.ExpiryDate.split('T')[0] : '';
                }
                document.getElementById('formTitle').textContent = 'Edit Payment Method';
                document.getElementById('formIcon').textContent = '✏️';
                document.querySelector('button[type="submit"]').textContent = '💾 Update Payment Method';
                document.getElementById('cancelEdit').classList.remove('hidden');
                isEditing = true;
            })
            .catch(error => {
                console.error('Error loading payment method:', error);
            });
    };

    window.deletePayment = (methodId) => {
        if (confirm('Are you sure you want to delete this payment method?')) {
            apiCall(`/payments/${methodId}`, { method: 'DELETE' })
                .then(() => loadPaymentMethods())
                .catch(error => {
                    console.error('Error deleting payment method:', error);
                    alert('Error deleting payment method');
                });
        }
    };

    document.getElementById('cancelEdit').addEventListener('click', () => {
        document.getElementById('paymentForm').reset();
        document.getElementById('editingId').value = '';
        document.getElementById('formTitle').textContent = 'Add Payment Method';
        document.getElementById('formIcon').textContent = '➕';
        document.querySelector('button[type="submit"]').textContent = '✨ Add Payment Method';
        document.getElementById('cancelEdit').classList.add('hidden');
        updatePaymentFields();
        isEditing = false;
    });

    document.getElementById('paymentForm').addEventListener('submit', async (e) => {
        e.preventDefault();

        const paymentType = document.getElementById('paymentType').value;
        const isUpi = paymentType === 'upi';
        const data = {
            paymentType,
            provider: document.getElementById('provider').value
        };

        if (isUpi) {
            data.upiId = document.getElementById('upiId').value.trim();
            data.expiryDate = null;
        } else {
            data.cardNumber = document.getElementById('cardNumber').value.trim();
            data.expiryDate = document.getElementById('expiryDate').value;
        }

        try {
            if (isEditing) {
                await apiCall(`/payments/${document.getElementById('editingId').value}`, {
                    method: 'PUT',
                    body: JSON.stringify(data)
                });
            } else {
                await apiCall('/payments', {
                    method: 'POST',
                    body: JSON.stringify(data)
                });
            }

            document.getElementById('paymentForm').reset();
            document.getElementById('editingId').value = '';
            document.getElementById('formTitle').textContent = 'Add Payment Method';
            document.getElementById('formIcon').textContent = '➕';
            document.querySelector('button[type="submit"]').textContent = '✨ Add Payment Method';
            document.getElementById('cancelEdit').classList.add('hidden');
            updatePaymentFields();
            isEditing = false;
            loadPaymentMethods();
        } catch (error) {
            console.error('Error saving payment method:', error);
            alert('Error saving payment method');
        }
    });

    loadPaymentMethods();
}

// Usage Logs Page
function initUsageLogs() {
    if (!checkAuth()) return;

    // Load subscriptions
    apiCall('/subscriptions')
        .then(subscriptions => {
            const activeSubs = subscriptions.filter(sub => sub.Status === 'Active');
            const select = document.getElementById('subId');
            activeSubs.forEach(sub => {
                const option = document.createElement('option');
                option.value = sub.SubID;
                option.textContent = `${sub.PlatformName} - ${sub.PlanName || 'No Plan'}`;
                select.appendChild(option);
            });
        })
        .catch(error => {
            console.error('Error loading subscriptions:', error);
        });

    // Handle subscription change
    document.getElementById('subId').addEventListener('change', (e) => {
        const subId = e.target.value;
        if (subId) {
            loadUsageLogs(subId);
        }
    });

    // Set default date
    document.getElementById('dateAccessed').value = new Date().toISOString().split('T')[0];

    // Form submission
    document.getElementById('usageForm').addEventListener('submit', async (e) => {
        e.preventDefault();

        const data = {
            subId: parseInt(document.getElementById('subId').value),
            dateAccessed: document.getElementById('dateAccessed').value,
            actionType: document.getElementById('actionType').value
        };

        try {
            await apiCall('/usage', {
                method: 'POST',
                body: JSON.stringify(data)
            });

            document.getElementById('actionType').value = '';
            document.getElementById('dateAccessed').value = new Date().toISOString().split('T')[0];
            loadUsageLogs(data.subId);
        } catch (error) {
            console.error('Error logging usage:', error);
            alert('Error logging usage');
        }
    });

    function loadUsageLogs(subId) {
        document.getElementById('usageTitle').textContent = 'Usage History';
        apiCall(`/usage/${subId}`)
            .then(logs => {
                const content = document.getElementById('usageLogsContent');
                if (logs.length === 0) {
                    content.innerHTML = `
                        <div class="text-center py-8">
                            <span class="text-5xl mb-4 block">📭</span>
                            <p class="text-gray-500 dark:text-gray-400">No usage logs found for this subscription</p>
                        </div>
                    `;
                } else {
                    content.innerHTML = `
                        <div class="max-h-96 overflow-y-auto">
                            <table class="min-w-full">
                                <thead class="bg-gradient-to-r from-gray-50 to-gray-100 dark:from-gray-700 dark:to-gray-800 sticky top-0">
                                    <tr>
                                        <th class="text-left py-3 px-4 font-semibold text-gray-700 dark:text-gray-300">Date</th>
                                        <th class="text-left py-3 px-4 font-semibold text-gray-700 dark:text-gray-300">Action</th>
                                        <th class="text-left py-3 px-4 font-semibold text-gray-700 dark:text-gray-300">Delete</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    ${logs.map(log => `
                                        <tr class="border-b border-gray-200 dark:border-gray-600 hover:bg-blue-50 dark:hover:bg-gray-700 transition">
                                            <td class="py-3 px-4 font-medium text-gray-900 dark:text-white">
                                                ${new Date(log.DateAccessed).toLocaleDateString()}
                                            </td>
                                            <td class="py-3 px-4">
                                                <span class="bg-blue-100 dark:bg-blue-900/30 text-blue-800 dark:text-blue-300 px-2 py-1 rounded-full text-sm">
                                                    ${log.ActionType}
                                                </span>
                                            </td>
                                            <td class="py-3 px-4">
                                                <button onclick="deleteUsageLog(${log.LogID}, ${subId})" class="text-red-600 hover:text-red-800 font-medium flex items-center">
                                                    <span class="mr-1">🗑️</span> Delete
                                                </button>
                                            </td>
                                        </tr>
                                    `).join('')}
                                </tbody>
                            </table>
                        </div>
                    `;
                }
            })
            .catch(error => {
                console.error('Error loading usage logs:', error);
            });
    }

    window.deleteUsageLog = (logId, subId) => {
        if (confirm('Are you sure you want to delete this usage log?')) {
            apiCall(`/usage/${logId}`, { method: 'DELETE' })
                .then(() => loadUsageLogs(subId))
                .catch(error => {
                    console.error('Error deleting usage log:', error);
                    alert('Error deleting usage log');
                });
        }
    };
}

// Pay a subscription from wallet (used by analytics high-risk Pay button)
window.paySubscription = async (subId, platformName) => {
    if (!confirm(`Pay for ${platformName || 'this subscription'} from your wallet?`)) return;
    try {
        const res = await apiCall('/wallet/pay', {
            method: 'POST',
            body: JSON.stringify({ subId })
        });
        alert(res.message);
    } catch (error) {
        alert(error.message || 'Payment failed');
    }
};

// Wallet Page
function initWallet() {
    if (!checkAuth()) return;

    let walletMethods = [];
    let qrScanner = null;
    let pendingQrPayment = null;

    const balanceEl = document.getElementById('walletBalance');
    const warningEl = document.getElementById('negativeWarning');

    function renderBalance(balance, negative) {
        balanceEl.textContent = `₹${parseFloat(balance).toFixed(2)}`;
        balanceEl.classList.toggle('text-red-200', negative);
        warningEl.classList.toggle('hidden', !negative);
    }

    function loadWallet() {
        apiCall('/wallet')
            .then(data => {
                renderBalance(data.balance, data.negativeBalance);
                renderTransactions(data.transactions);
            })
            .catch(error => console.error('Error loading wallet:', error));
    }

    function renderTransactions(txs) {
        const body = document.getElementById('transactionsBody');
        if (!txs || txs.length === 0) {
            body.innerHTML = '<tr><td colspan="4" class="text-center py-8 text-gray-500 dark:text-gray-400">No transactions this month</td></tr>';
            return;
        }
        body.innerHTML = txs.map(t => `
            <tr class="border-b border-gray-200 dark:border-gray-600 hover:bg-blue-50 dark:hover:bg-gray-700 transition">
                <td class="py-3 px-4 text-gray-900 dark:text-white">${new Date(t.CreatedAt).toLocaleString()}</td>
                <td class="py-3 px-4 text-gray-900 dark:text-white">${t.Description || '-'}</td>
                <td class="py-3 px-4">
                    <span class="px-2 py-1 rounded-full text-xs font-semibold ${t.Type === 'credit' ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'}">
                        ${t.Type === 'credit' ? 'Credit' : 'Debit'}
                    </span>
                </td>
                <td class="py-3 px-4 text-right font-semibold ${t.Type === 'credit' ? 'text-green-600' : 'text-red-600'}">
                    ${t.Type === 'credit' ? '+' : '-'}₹${parseFloat(t.Amount).toFixed(2)}
                </td>
            </tr>
        `).join('');
    }

    function methodLabel(m) {
        return m.PaymentType === 'upi' ? `📱 UPI - ${m.UPIID}` : `${m.PaymentType === 'debit_card' ? '🏧' : '💳'} ${m.Provider} - ****${m.CardLast4}`;
    }

    function loadPaymentMethods() {
        apiCall('/payments')
            .then(methods => {
                walletMethods = methods;

                const select = document.getElementById('fundMethod');
                select.innerHTML = '<option value="">Select a method</option>';
                methods.forEach(m => {
                    const opt = document.createElement('option');
                    opt.value = m.MethodID;
                    opt.textContent = methodLabel(m);
                    select.appendChild(opt);
                });

                const list = document.getElementById('walletPaymentMethods');
                if (methods.length === 0) {
                    list.innerHTML = '<p class="text-gray-500 dark:text-gray-400 text-sm">No payment methods saved yet. <a href="payment-methods.html" class="text-blue-600 hover:underline">Add one →</a></p>';
                } else {
                    list.innerHTML = methods.map(m => `
                        <div class="flex items-center justify-between border border-gray-200 dark:border-gray-600 rounded-lg p-3">
                            <span class="text-sm font-medium text-gray-800 dark:text-gray-200">${methodLabel(m)}</span>
                            ${m.PaymentType !== 'upi' ? `<span class="text-xs text-gray-400">Exp ${m.ExpiryDate ? new Date(m.ExpiryDate).toLocaleDateString() : '-'}</span>` : ''}
                        </div>
                    `).join('');
                }
            })
            .catch(error => console.error('Error loading payment methods:', error));
    }

    function selectedMethod() {
        const id = document.getElementById('fundMethod').value;
        return walletMethods.find(m => String(m.MethodID) === String(id));
    }

    function updateFundFields() {
        const m = selectedMethod();
        const isCard = m && m.PaymentType !== 'upi';
        document.getElementById('cvvField').classList.toggle('hidden', !isCard);
        if (isCard) document.getElementById('fundCvv').required = true;
        else document.getElementById('fundCvv').required = false;
        if (m && m.PaymentType === 'upi') showUpiQr(m);
        else document.getElementById('upiQrBox').classList.add('hidden');
    }

    function showUpiQr(method) {
        const m = method || walletMethods.find(x => x.PaymentType === 'upi');
        const amount = document.getElementById('fundAmount').value || '0';
        if (!m || !m.UPIID) {
            alert('No UPI payment method found. Add one from Payment Methods page.');
            return;
        }
        const upiText = `upi://pay?pa=${encodeURIComponent(m.UPIID)}&pn=${encodeURIComponent('Subscription Wallet')}&am=${encodeURIComponent(amount)}&cu=INR`;
        const box = document.getElementById('upiQrBox');
        const qrEl = document.getElementById('upiQrCode');
        qrEl.innerHTML = '';
        if (typeof QRCode !== 'undefined') {
            new QRCode(qrEl, { text: upiText, width: 128, height: 128 });
        } else {
            qrEl.innerHTML = `<p class="text-xs break-all">${upiText}</p>`;
        }
        document.getElementById('upiQrInfo').textContent = `Pay ₹${amount} to ${m.UPIID}`;
        box.classList.remove('hidden');
    }

    document.getElementById('fundMethod').addEventListener('change', updateFundFields);
    document.getElementById('fundAmount').addEventListener('input', () => {
        const m = selectedMethod();
        if (m && m.PaymentType === 'upi') showUpiQr(m);
    });
    document.getElementById('showQrBtn').addEventListener('click', () => showUpiQr());

    document.getElementById('addFundsBtn').addEventListener('click', async () => {
        const amount = parseFloat(document.getElementById('fundAmount').value);
        const method = selectedMethod();
        if (!amount || amount <= 0) { alert('Enter a valid amount'); return; }
        if (!method) { alert('Select a payment method'); return; }
        const cvv = document.getElementById('fundCvv').value;
        if (method.PaymentType !== 'upi' && (!cvv || !/^\d{3,4}$/.test(cvv))) {
            alert('Enter the card CVV'); return;
        }
        try {
            const res = await apiCall('/wallet/add-funds', {
                method: 'POST',
                body: JSON.stringify({ amount, paymentMethodId: method.MethodID, cvv })
            });
            renderBalance(res.balance, res.balance < 0);
            document.getElementById('fundAmount').value = '';
            document.getElementById('fundCvv').value = '';
            alert(res.message);
            loadWallet();
        } catch (error) {
            alert(error.message || 'Failed to add funds');
        }
    });

    // QR Scanner
    function stopScanner() {
        if (qrScanner) {
            qrScanner.stop().then(() => qrScanner.clear()).catch(() => {});
            qrScanner = null;
        }
    }

    document.getElementById('scanQrBtn').addEventListener('click', () => {
        document.getElementById('scannerModal').classList.remove('hidden');
        document.getElementById('scanResult').classList.add('hidden');
        document.getElementById('confirmScanPay').classList.add('hidden');
        document.getElementById('cancelScanPay').classList.add('hidden');
        pendingQrPayment = null;

        if (typeof Html5Qrcode === 'undefined') {
            alert('QR scanner library failed to load. Check your internet connection.');
            return;
        }
        qrScanner = new Html5Qrcode('qrScanner');
        qrScanner.start(
            { facingMode: 'environment' },
            { fps: 10, qrbox: 250 },
            onScanSuccess,
            () => {}
        ).catch(err => {
            console.error('Camera error:', err);
            document.getElementById('scanResult').innerHTML = '<p class="text-red-600">⚠️ Could not access camera. Allow camera permission and try again.</p>';
            document.getElementById('scanResult').classList.remove('hidden');
        });
    });

    function onScanSuccess(decodedText) {
        stopScanner();
        pendingQrPayment = parseUpiQr(decodedText);
        const resultEl = document.getElementById('scanResult');
        if (pendingQrPayment) {
            resultEl.innerHTML = `<p>📱 Pay <strong>₹${pendingQrPayment.amount}</strong> to <strong>${pendingQrPayment.upiId}</strong>?</p>`;
        } else {
            resultEl.innerHTML = `<p>Scanned: ${decodedText}</p><p class="mt-1">Not a valid UPI QR code.</p>`;
            pendingQrPayment = null;
        }
        resultEl.classList.remove('hidden');
        document.getElementById('confirmScanPay').classList.toggle('hidden', !pendingQrPayment);
        document.getElementById('cancelScanPay').classList.remove('hidden');
    }

    function parseUpiQr(text) {
        try {
            const url = new URL(text);
            if (url.protocol !== 'upi:') return null;
            const pa = url.searchParams.get('pa');
            if (!pa) return null;
            return { upiId: pa, amount: parseFloat(url.searchParams.get('am')) || null };
        } catch (e) {
            return null;
        }
    }

    document.getElementById('confirmScanPay').addEventListener('click', async () => {
        if (!pendingQrPayment) return;
        let amount = pendingQrPayment.amount;
        if (!amount) {
            const input = prompt('Enter amount to pay (₹):');
            amount = parseFloat(input);
            if (!amount || amount <= 0) return;
        }
        try {
            const res = await apiCall('/wallet/pay-qr', {
                method: 'POST',
                body: JSON.stringify({ upiId: pendingQrPayment.upiId, amount })
            });
            renderBalance(res.balance, res.balance < 0);
            document.getElementById('scannerModal').classList.add('hidden');
            alert(res.message);
            loadWallet();
        } catch (error) {
            alert(error.message || 'Payment failed');
        }
    });

    document.getElementById('cancelScanPay').addEventListener('click', () => {
        document.getElementById('scannerModal').classList.add('hidden');
    });
    document.getElementById('closeScanner').addEventListener('click', () => {
        stopScanner();
        document.getElementById('scannerModal').classList.add('hidden');
    });

    loadWallet();
    loadPaymentMethods();
}

// Password visibility toggles (eye SVG buttons with .password-toggle class)
function initPasswordToggles() {
    document.querySelectorAll('.password-toggle').forEach(btn => {
        btn.addEventListener('click', () => {
            const input = document.getElementById(btn.dataset.target);
            if (!input) return;
            const show = input.type === 'password';
            input.type = show ? 'text' : 'password';
            btn.querySelector('.eye-icon').classList.toggle('hidden', !show);
            btn.querySelector('.eye-off-icon').classList.toggle('hidden', show);
        });
    });
}

// Forgot / Reset Password (login page)
function handleResetPassword() {
    const showReset = document.getElementById('showReset');
    const resetSection = document.getElementById('resetSection');
    const resetForm = document.getElementById('resetForm');
    if (!showReset || !resetSection || !resetForm) return;

    showReset.addEventListener('click', (e) => {
        e.preventDefault();
        resetSection.classList.toggle('hidden');
    });

    document.getElementById('cancelReset').addEventListener('click', () => {
        resetSection.classList.add('hidden');
        resetForm.reset();
        document.getElementById('resetMessage').classList.add('hidden');
    });

    resetForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        const email = document.getElementById('resetEmail').value;
        const newPassword = document.getElementById('resetPassword').value;
        const confirm = document.getElementById('resetConfirm').value;
        const msgEl = document.getElementById('resetMessage');

        msgEl.classList.add('hidden');

        if (newPassword !== confirm) {
            showError('Passwords do not match');
            return;
        }
        if (newPassword.length < 6) {
            showError('Password must be at least 6 characters');
            return;
        }

        try {
            const res = await apiCall('/auth/reset-password', {
                method: 'POST',
                body: JSON.stringify({ email, newPassword })
            });
            msgEl.textContent = res.message;
            msgEl.classList.remove('hidden');
            resetForm.reset();
            setTimeout(() => resetSection.classList.add('hidden'), 2000);
        } catch (error) {
            showError(error.message);
        }
    });
}

// Initialize based on current page
document.addEventListener('DOMContentLoaded', () => {
    initDarkMode();
    handleLogout();
    initAccountMenu();
    initPasswordToggles();

    const path = window.location.pathname;

    if (path.includes('login.html')) {
        handleLogin();
        handleResetPassword();
    } else if (path.includes('register.html')) {
        handleRegister();
    } else if (path.includes('dashboard.html')) {
        updateUserDisplay();
        initDashboard();
        initDashboardCards();
    } else if (path.includes('subscriptions.html')) {
        updateUserDisplay();
        initSubscriptions();
    } else if (path.includes('subscription-form.html')) {
        updateUserDisplay();
        initSubscriptionForm();
    } else if (path.includes('analytics.html')) {
        updateUserDisplay();
        initAnalytics();
    } else if (path.includes('payment-methods.html')) {
        updateUserDisplay();
        initPaymentMethods();
    } else if (path.includes('usage-logs.html')) {
        updateUserDisplay();
        initUsageLogs();
    } else if (path.includes('wallet.html')) {
        updateUserDisplay();
        initWallet();
    }

    // Dark mode toggle
    const darkModeToggle = document.getElementById('darkModeToggle');
    if (darkModeToggle) {
        darkModeToggle.addEventListener('click', toggleDarkMode);
    }
});
