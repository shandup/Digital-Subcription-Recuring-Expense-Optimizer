const express = require('express');
const router = express.Router();
const { getAllPaymentMethods, createPaymentMethod, updatePaymentMethod, deletePaymentMethod } = require('../controllers/paymentController');
const auth = require('../middleware/auth');

router.get('/', auth, getAllPaymentMethods);
router.post('/', auth, createPaymentMethod);
router.put('/:id', auth, updatePaymentMethod);
router.delete('/:id', auth, deletePaymentMethod);

module.exports = router;
