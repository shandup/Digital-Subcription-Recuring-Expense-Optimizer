const express = require('express');
const router = express.Router();
const { getAlertRules, createAlertRule, updateAlertRule, deleteAlertRule } = require('../controllers/alertController');
const auth = require('../middleware/auth');

router.get('/:subId', auth, getAlertRules);
router.post('/', auth, createAlertRule);
router.put('/:ruleId', auth, updateAlertRule);
router.delete('/:ruleId', auth, deleteAlertRule);

module.exports = router;
