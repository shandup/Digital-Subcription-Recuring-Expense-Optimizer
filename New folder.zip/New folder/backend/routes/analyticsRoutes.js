const express = require('express');
const router = express.Router();
const { getWasteReport, getDashboardData } = require('../controllers/analyticsController');
const auth = require('../middleware/auth');

router.get('/waste-report', auth, getWasteReport);
router.get('/dashboard', auth, getDashboardData);

module.exports = router;
