const express = require('express');
const router = express.Router();
const { getUsageLogs, createUsageLog, deleteUsageLog } = require('../controllers/usageController');
const auth = require('../middleware/auth');

router.get('/:subId', auth, getUsageLogs);
router.post('/', auth, createUsageLog);
router.delete('/:logId', auth, deleteUsageLog);

module.exports = router;
