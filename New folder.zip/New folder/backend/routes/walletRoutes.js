const express = require('express');
const router = express.Router();
const { getWallet, addFunds, paySubscription, payQr } = require('../controllers/walletController');
const auth = require('../middleware/auth');

router.get('/', auth, getWallet);
router.post('/add-funds', auth, addFunds);
router.post('/pay', auth, paySubscription);
router.post('/pay-qr', auth, payQr);

module.exports = router;
