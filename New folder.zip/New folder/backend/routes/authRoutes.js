const express = require('express');
const router = express.Router();
const { register, login, getProfile, updateProfile, updatePassword, updatePhoto, resetPassword } = require('../controllers/authController');
const auth = require('../middleware/auth');

router.post('/register', register);
router.post('/login', login);
router.post('/reset-password', resetPassword);
router.get('/profile', auth, getProfile);
router.put('/profile', auth, updateProfile);
router.put('/password', auth, updatePassword);
router.put('/photo', auth, updatePhoto);

module.exports = router;
