require('dotenv').config();
const m = require('mysql2/promise');
(async () => {
    const c = await m.createConnection({
        host: process.env.DB_HOST,
        user: process.env.DB_USER,
        password: process.env.DB_PASSWORD,
        database: process.env.DB_NAME
    });
    const alters = [
        'ALTER TABLE Users ADD COLUMN WalletBalance DECIMAL(10,2) NOT NULL DEFAULT 0',
        'ALTER TABLE Subscriptions ADD COLUMN WebsiteURL VARCHAR(255) NULL',
        `CREATE TABLE IF NOT EXISTS Transactions (
            TransactionID INT AUTO_INCREMENT PRIMARY KEY,
            UserID INT NOT NULL,
            Type ENUM('credit', 'debit') NOT NULL,
            Amount DECIMAL(10,2) NOT NULL,
            Description VARCHAR(255),
            SubID INT NULL,
            CreatedAt DATETIME DEFAULT CURRENT_TIMESTAMP,
            CONSTRAINT fk_transaction_user FOREIGN KEY (UserID)
                REFERENCES Users(UserID)
                ON DELETE CASCADE,
            CONSTRAINT fk_transaction_subscription FOREIGN KEY (SubID)
                REFERENCES Subscriptions(SubID)
                ON DELETE SET NULL,
            INDEX idx_user_date (UserID, CreatedAt)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`
    ];
    for (const sql of alters) {
        try {
            await c.query(sql);
            console.log('OK:', sql.slice(0, 60));
        } catch (e) {
            console.log('SKIP/ERR:', e.message);
        }
    }
    await c.end();
})();
