const fs = require('fs');
const path = require('path');
const mysql = require('mysql2/promise');
require('dotenv').config({ path: path.join(__dirname, '..', '.env') });

const DB_NAME = process.env.DB_NAME || 'subscription_optimizer';
const DB_DIR = path.join(__dirname, '..', '..', 'database');
const seedOnly = process.argv.includes('--seed-only');
const runSeed = process.argv.includes('--seed') || seedOnly;

async function runSqlFile(conn, file) {
    const sql = fs.readFileSync(path.join(DB_DIR, file), 'utf8');
    await conn.query(sql);
    console.log(`${file} applied successfully`);
}

async function main() {
    const conn = await mysql.createConnection({
        host: process.env.DB_HOST || 'localhost',
        user: process.env.DB_USER || 'root',
        password: process.env.DB_PASSWORD || '',
        port: parseInt(process.env.DB_PORT, 10) || 3306,
        multipleStatements: true
    });

    await conn.query(
        `CREATE DATABASE IF NOT EXISTS \`${DB_NAME}\` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci`
    );
    console.log(`Database '${DB_NAME}' ready`);

    await conn.changeUser({ database: DB_NAME });
    if (!seedOnly) {
        await runSqlFile(conn, 'schema.sql');
    }

    if (runSeed) {
        await runSqlFile(conn, 'seed.sql');
    }

    await conn.end();
    console.log('Done.');
}

main().catch(err => {
    console.error('Setup failed:', err.message);
    process.exit(1);
});
