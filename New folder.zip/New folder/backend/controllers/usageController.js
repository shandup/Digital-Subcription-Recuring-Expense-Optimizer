const pool = require('../config/database');

const getUsageLogs = async (req, res) => {
    try {
        const [logs] = await pool.query(
            `SELECT ul.*, s.PlatformName 
             FROM Usage_Logs ul 
             JOIN Subscriptions s ON ul.SubID = s.SubID 
             WHERE s.UserID = ? AND ul.SubID = ?
             ORDER BY ul.DateAccessed DESC`,
            [req.user.userId, req.params.subId]
        );
        res.json(logs);
    } catch (error) {
        console.error('Error fetching usage logs:', error);
        res.status(500).json({ error: 'Failed to fetch usage logs' });
    }
};

const createUsageLog = async (req, res) => {
    try {
        const { subId, dateAccessed, actionType } = req.body;

        // Verify subscription belongs to user
        const [subscriptions] = await pool.query(
            'SELECT * FROM Subscriptions WHERE SubID = ? AND UserID = ?',
            [subId, req.user.userId]
        );

        if (subscriptions.length === 0) {
            return res.status(404).json({ error: 'Subscription not found' });
        }

        const [result] = await pool.query(
            'INSERT INTO Usage_Logs (SubID, DateAccessed, ActionType) VALUES (?, ?, ?)',
            [subId, dateAccessed, actionType]
        );

        const [newLog] = await pool.query(
            `SELECT ul.*, s.PlatformName 
             FROM Usage_Logs ul 
             JOIN Subscriptions s ON ul.SubID = s.SubID 
             WHERE ul.LogID = ?`,
            [result.insertId]
        );

        res.status(201).json(newLog[0]);
    } catch (error) {
        console.error('Error creating usage log:', error);
        res.status(500).json({ error: 'Failed to create usage log' });
    }
};

const deleteUsageLog = async (req, res) => {
    try {
        const [result] = await pool.query(
            `DELETE ul FROM Usage_Logs ul 
             JOIN Subscriptions s ON ul.SubID = s.SubID 
             WHERE ul.LogID = ? AND s.UserID = ?`,
            [req.params.logId, req.user.userId]
        );

        if (result.affectedRows === 0) {
            return res.status(404).json({ error: 'Usage log not found' });
        }

        res.json({ message: 'Usage log deleted successfully' });
    } catch (error) {
        console.error('Error deleting usage log:', error);
        res.status(500).json({ error: 'Failed to delete usage log' });
    }
};

module.exports = {
    getUsageLogs,
    createUsageLog,
    deleteUsageLog
};
