const pool = require('../config/database');
const { processDuePayments } = require('./walletController');

const getWasteReport = async (req, res) => {
    try {
        const [report] = await pool.query(
            `SELECT
                s.SubID,
                s.PlatformName,
                s.PlanName,
                s.Cost,
                s.BillingCycle,
                s.NextRenewalDate,
                MAX(u.DateAccessed) AS LastUsedDate,
                COALESCE(DATEDIFF(CURRENT_DATE, MAX(u.DateAccessed)), 999) AS DaysSinceLastUse,
                CASE
                    WHEN DATEDIFF(CURRENT_DATE, MAX(u.DateAccessed)) > 30
                    OR MAX(u.DateAccessed) IS NULL
                    THEN 'High Risk - Consider Canceling'
                    ELSE 'Active Engagement'
                END AS WasteRecommendation
            FROM Subscriptions s
            LEFT JOIN Usage_Logs u ON s.SubID = u.SubID
            WHERE s.UserID = ? AND s.Status = 'Active'
            GROUP BY s.SubID, s.PlatformName, s.PlanName, s.Cost, s.BillingCycle, s.NextRenewalDate
            ORDER BY DaysSinceLastUse DESC`,
            [req.user.userId]
        );
        res.json(report);
    } catch (error) {
        console.error('Error fetching waste report:', error);
        res.status(500).json({ error: 'Failed to fetch waste report' });
    }
};

const getDashboardData = async (req, res) => {
    try {
        await processDuePayments(req.user.userId);

        // Get status counts
        const [statusCounts] = await pool.query(
            `SELECT Status, COUNT(*) as count 
             FROM Subscriptions 
             WHERE UserID = ? 
             GROUP BY Status`,
            [req.user.userId]
        );

        const statusCountsObj = statusCounts.reduce((acc, row) => {
            acc[row.Status] = row.count;
            return acc;
        }, {});

        // Get upcoming renewals (next 30 days)
        const [upcomingRenewals] = await pool.query(
            `SELECT s.SubID, s.PlatformName, s.Cost, s.NextRenewalDate 
             FROM Subscriptions s 
             WHERE s.UserID = ? AND s.Status = 'Active' 
             AND s.NextRenewalDate BETWEEN CURDATE() AND DATE_ADD(CURDATE(), INTERVAL 30 DAY)
             ORDER BY s.NextRenewalDate ASC`,
            [req.user.userId]
        );

        // Get total monthly cost (normalized)
        const [totalCost] = await pool.query(
            `SELECT 
                SUM(
                    CASE 
                        WHEN BillingCycle = 'Monthly' THEN Cost
                        WHEN BillingCycle = 'Quarterly' THEN Cost / 3
                        WHEN BillingCycle = 'Annual' THEN Cost / 12
                    END
                ) as totalMonthlyCost
             FROM Subscriptions 
             WHERE UserID = ? AND Status = 'Active'`,
            [req.user.userId]
        );

        // Get recent usage
        const [recentUsage] = await pool.query(
            `SELECT ul.*, s.PlatformName 
             FROM Usage_Logs ul 
             JOIN Subscriptions s ON ul.SubID = s.SubID 
             WHERE s.UserID = ? 
             ORDER BY ul.DateAccessed DESC 
             LIMIT 10`,
            [req.user.userId]
        );

        res.json({
            statusCounts: statusCountsObj,
            upcomingRenewals,
            totalMonthlyCost: totalCost[0].totalMonthlyCost || 0,
            recentUsage
        });
    } catch (error) {
        console.error('Error fetching dashboard data:', error);
        res.status(500).json({ error: 'Failed to fetch dashboard data' });
    }
};

module.exports = {
    getWasteReport,
    getDashboardData
};
