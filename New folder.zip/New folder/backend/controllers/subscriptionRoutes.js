const express = require('express');
const router = express.Router();
const { getAllSubscriptions, getSubscriptionById, createSubscription, updateSubscription, updateStatus, deleteSubscription } = require('../controllers/subscriptionController');
const auth = require('../middleware/auth');

router.get('/', auth, getAllSubscriptions);
router.get('/:id', auth, getSubscriptionById);
router.post('/', auth, createSubscription);
router.put('/:id', auth, updateSubscription);
router.patch('/:id/status', auth, updateStatus);
router.delete('/:id', auth, deleteSubscription);

module.exports = router;
