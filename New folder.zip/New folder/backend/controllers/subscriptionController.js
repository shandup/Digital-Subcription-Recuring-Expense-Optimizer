const pool = require('../config/database');
const { processDuePayments } = require('./walletController');

const calculateNextRenewalDate = (startDate, billingCycle) => {
    const start = new Date(startDate);
    const nextRenewal = new Date(start);

    switch (billingCycle) {
        case 'Monthly':
            nextRenewal.setMonth(nextRenewal.getMonth() + 1);
            break;
        case 'Quarterly':
            nextRenewal.setMonth(nextRenewal.getMonth() + 3);
            break;
        case 'Annual':
            nextRenewal.setFullYear(nextRenewal.getFullYear() + 1);
            break;
    }

    return nextRenewal.toISOString().split('T')[0];
};

const getAllSubscriptions = async (req, res) => {
    try {
        await processDuePayments(req.user.userId);
        const [subscriptions] = await pool.query(
            `SELECT s.*, pm.Provider, pm.CardLast4 
             FROM Subscriptions s 
             LEFT JOIN Payment_Methods pm ON s.MethodID = pm.MethodID 
             WHERE s.UserID = ? 
             ORDER BY s.NextRenewalDate ASC`,
            [req.user.userId]
        );
        res.json(subscriptions);
    } catch (error) {
        console.error('Error fetching subscriptions:', error);
        res.status(500).json({ error: 'Failed to fetch subscriptions' });
    }
};

const getSubscriptionById = async (req, res) => {
    try {
        const [subscriptions] = await pool.query(
            `SELECT s.*, pm.Provider, pm.CardLast4 
             FROM Subscriptions s 
             LEFT JOIN Payment_Methods pm ON s.MethodID = pm.MethodID 
             WHERE s.SubID = ? AND s.UserID = ?`,
            [req.params.id, req.user.userId]
        );

        if (subscriptions.length === 0) {
            return res.status(404).json({ error: 'Subscription not found' });
        }

        res.json(subscriptions[0]);
    } catch (error) {
        console.error('Error fetching subscription:', error);
        res.status(500).json({ error: 'Failed to fetch subscription' });
    }
};

const createSubscription = async (req, res) => {
    const connection = await pool.getConnection();
    try {
        await connection.beginTransaction();

        const { platformName, planName, cost, billingCycle, startDate, methodId, websiteUrl, autoRenew } = req.body;
        const nextRenewalDate = calculateNextRenewalDate(startDate, billingCycle);

        const [result] = await connection.query(
            `INSERT INTO Subscriptions (UserID, MethodID, WebsiteURL, PlatformName, PlanName, Cost, BillingCycle, StartDate, NextRenewalDate, Status, AutoRenew) 
             VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'Active', ?)`,
            [req.user.userId, methodId || null, websiteUrl || null, platformName, planName, cost, billingCycle, startDate, nextRenewalDate, autoRenew === undefined || autoRenew === null ? true : autoRenew]
        );

        // Create default alert rule
        await connection.query(
            `INSERT INTO Alert_Rules (SubID, DaysBeforeRenewal, IsActive) 
             VALUES (?, 7, TRUE)`,
            [result.insertId]
        );

        await connection.commit();

        const [newSubscription] = await connection.query(
            `SELECT s.*, pm.Provider, pm.CardLast4 
             FROM Subscriptions s 
             LEFT JOIN Payment_Methods pm ON s.MethodID = pm.MethodID 
             WHERE s.SubID = ?`,
            [result.insertId]
        );

        res.status(201).json(newSubscription[0]);
    } catch (error) {
        await connection.rollback();
        console.error('Error creating subscription:', error);
        res.status(500).json({ error: 'Failed to create subscription' });
    } finally {
        connection.release();
    }
};

const updateSubscription = async (req, res) => {
    try {
        const { platformName, planName, cost, billingCycle, startDate, methodId, status, websiteUrl, autoRenew } = req.body;
        const nextRenewalDate = calculateNextRenewalDate(startDate, billingCycle);

        const [result] = await pool.query(
            `UPDATE Subscriptions 
             SET PlatformName = ?, PlanName = ?, Cost = ?, BillingCycle = ?, 
                 StartDate = ?, NextRenewalDate = ?, MethodID = ?, Status = ?, WebsiteURL = ?, AutoRenew = ?
             WHERE SubID = ? AND UserID = ?`,
            [platformName, planName, cost, billingCycle, startDate, nextRenewalDate, methodId || null, status, websiteUrl || null, autoRenew === undefined || autoRenew === null ? true : autoRenew, req.params.id, req.user.userId]
        );

        if (result.affectedRows === 0) {
            return res.status(404).json({ error: 'Subscription not found' });
        }

        const [updated] = await pool.query(
            `SELECT s.*, pm.Provider, pm.CardLast4 
             FROM Subscriptions s 
             LEFT JOIN Payment_Methods pm ON s.MethodID = pm.MethodID 
             WHERE s.SubID = ?`,
            [req.params.id]
        );

        res.json(updated[0]);
    } catch (error) {
        console.error('Error updating subscription:', error);
        res.status(500).json({ error: 'Failed to update subscription' });
    }
};

const updateStatus = async (req, res) => {
    try {
        const { status } = req.body;

        if (!['Active', 'Paused', 'Cancelled'].includes(status)) {
            return res.status(400).json({ error: 'Invalid status' });
        }

        // If pausing, also disable auto-renewal. If activating, re-enable auto-renewal.
        let sql = 'UPDATE Subscriptions SET Status = ? WHERE SubID = ? AND UserID = ?';
        let params = [status, req.params.id, req.user.userId];

        if (status === 'Paused') {
            sql = 'UPDATE Subscriptions SET Status = ?, AutoRenew = FALSE WHERE SubID = ? AND UserID = ?';
        } else if (status === 'Active') {
            sql = 'UPDATE Subscriptions SET Status = ?, AutoRenew = TRUE WHERE SubID = ? AND UserID = ?';
        }

        const [result] = await pool.query(sql, params);

        if (result.affectedRows === 0) {
            return res.status(404).json({ error: 'Subscription not found' });
        }

        const [updated] = await pool.query(
            `SELECT s.*, pm.Provider, pm.CardLast4 
             FROM Subscriptions s 
             LEFT JOIN Payment_Methods pm ON s.MethodID = pm.MethodID 
             WHERE s.SubID = ?`,
            [req.params.id]
        );

        res.json(updated[0]);
    } catch (error) {
        console.error('Error updating subscription status:', error);
        res.status(500).json({ error: 'Failed to update subscription status' });
    }
};

const deleteSubscription = async (req, res) => {
    try {
        const [result] = await pool.query(
            'DELETE FROM Subscriptions WHERE SubID = ? AND UserID = ?',
            [req.params.id, req.user.userId]
        );

        if (result.affectedRows === 0) {
            return res.status(404).json({ error: 'Subscription not found' });
        }

        res.json({ message: 'Subscription deleted successfully' });
    } catch (error) {
        console.error('Error deleting subscription:', error);
        res.status(500).json({ error: 'Failed to delete subscription' });
    }
};

const toggleAutoRenew = async (req, res) => {
    try {
        const { autoRenew } = req.body;

        if (typeof autoRenew !== 'boolean') {
            return res.status(400).json({ error: 'autoRenew must be true or false' });
        }

        const [result] = await pool.query(
            'UPDATE Subscriptions SET AutoRenew = ? WHERE SubID = ? AND UserID = ?',
            [autoRenew, req.params.id, req.user.userId]
        );

        if (result.affectedRows === 0) {
            return res.status(404).json({ error: 'Subscription not found' });
        }

        res.json({ message: autoRenew ? 'Auto-renewal enabled' : 'Auto-renewal disabled' });
    } catch (error) {
        console.error('Error toggling auto-renewal:', error);
        res.status(500).json({ error: 'Failed to toggle auto-renewal' });
    }
};

module.exports = {
    getAllSubscriptions,
    getSubscriptionById,
    createSubscription,
    updateSubscription,
    updateStatus,
    deleteSubscription,
    toggleAutoRenew
};
