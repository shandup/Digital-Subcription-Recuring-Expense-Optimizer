const pool = require('../config/database');

const getAllPaymentMethods = async (req, res) => {
    try {
        const [methods] = await pool.query(
            'SELECT * FROM Payment_Methods WHERE UserID = ?',
            [req.user.userId]
        );
        res.json(methods);
    } catch (error) {
        console.error('Error fetching payment methods:', error);
        res.status(500).json({ error: 'Failed to fetch payment methods' });
    }
};

const resolvePaymentDetails = (body) => {
    const { provider, cardLast4, cardNumber, upiId, expiryDate, paymentType } = body;

    if (paymentType === 'upi') {
        if (!upiId || !upiId.trim()) {
            return { error: 'UPI ID is required' };
        }
        return {
            provider,
            cardLast4: null,
            upiId: upiId.trim(),
            expiryDate: expiryDate || null,
            paymentType
        };
    }

    let last4 = cardLast4;
    if (cardNumber) {
        const digits = String(cardNumber).replace(/\D/g, '');
        if (digits.length < 12 || digits.length > 19) {
            return { error: 'Enter a valid card number' };
        }
        last4 = digits.slice(-4);
    }

    if (!last4 || !/^\d{4}$/.test(last4)) {
        return { error: 'Card last 4 digits are required' };
    }

    return { provider, cardLast4: last4, upiId: null, expiryDate, paymentType };
};

const createPaymentMethod = async (req, res) => {
    try {
        const details = resolvePaymentDetails(req.body);
        if (details.error) {
            return res.status(400).json({ error: details.error });
        }

        const [result] = await pool.query(
            'INSERT INTO Payment_Methods (UserID, Provider, CardLast4, ExpiryDate, PaymentType, UPIID) VALUES (?, ?, ?, ?, ?, ?)',
            [req.user.userId, details.provider, details.cardLast4, details.expiryDate, details.paymentType, details.upiId]
        );

        const [newMethod] = await pool.query(
            'SELECT * FROM Payment_Methods WHERE MethodID = ?',
            [result.insertId]
        );

        res.status(201).json(newMethod[0]);
    } catch (error) {
        console.error('Error creating payment method:', error);
        res.status(500).json({ error: 'Failed to create payment method' });
    }
};

const updatePaymentMethod = async (req, res) => {
    try {
        const details = resolvePaymentDetails(req.body);
        if (details.error) {
            return res.status(400).json({ error: details.error });
        }

        const [result] = await pool.query(
            'UPDATE Payment_Methods SET Provider = ?, CardLast4 = ?, ExpiryDate = ?, PaymentType = ?, UPIID = ? WHERE MethodID = ? AND UserID = ?',
            [details.provider, details.cardLast4, details.expiryDate, details.paymentType, details.upiId, req.params.id, req.user.userId]
        );

        if (result.affectedRows === 0) {
            return res.status(404).json({ error: 'Payment method not found' });
        }

        const [updated] = await pool.query(
            'SELECT * FROM Payment_Methods WHERE MethodID = ?',
            [req.params.id]
        );

        res.json(updated[0]);
    } catch (error) {
        console.error('Error updating payment method:', error);
        res.status(500).json({ error: 'Failed to update payment method' });
    }
};

const deletePaymentMethod = async (req, res) => {
    try {
        const [result] = await pool.query(
            'DELETE FROM Payment_Methods WHERE MethodID = ? AND UserID = ?',
            [req.params.id, req.user.userId]
        );

        if (result.affectedRows === 0) {
            return res.status(404).json({ error: 'Payment method not found' });
        }

        res.json({ message: 'Payment method deleted successfully' });
    } catch (error) {
        console.error('Error deleting payment method:', error);
        res.status(500).json({ error: 'Failed to delete payment method' });
    }
};

module.exports = {
    getAllPaymentMethods,
    createPaymentMethod,
    updatePaymentMethod,
    deletePaymentMethod
};
