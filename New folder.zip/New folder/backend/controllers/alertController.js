const pool = require('../config/database');

const getAlertRules = async (req, res) => {
    try {
        const [rules] = await pool.query(
            `SELECT ar.*, s.PlatformName 
             FROM Alert_Rules ar 
             JOIN Subscriptions s ON ar.SubID = s.SubID 
             WHERE s.UserID = ? AND ar.SubID = ?`,
            [req.user.userId, req.params.subId]
        );
        res.json(rules);
    } catch (error) {
        console.error('Error fetching alert rules:', error);
        res.status(500).json({ error: 'Failed to fetch alert rules' });
    }
};

const createAlertRule = async (req, res) => {
    try {
        const { subId, daysBeforeRenewal, isActive } = req.body;

        // Verify subscription belongs to user
        const [subscriptions] = await pool.query(
            'SELECT * FROM Subscriptions WHERE SubID = ? AND UserID = ?',
            [subId, req.user.userId]
        );

        if (subscriptions.length === 0) {
            return res.status(404).json({ error: 'Subscription not found' });
        }

        const [result] = await pool.query(
            'INSERT INTO Alert_Rules (SubID, DaysBeforeRenewal, IsActive) VALUES (?, ?, ?)',
            [subId, daysBeforeRenewal, isActive !== undefined ? isActive : true]
        );

        const [newRule] = await pool.query(
            `SELECT ar.*, s.PlatformName 
             FROM Alert_Rules ar 
             JOIN Subscriptions s ON ar.SubID = s.SubID 
             WHERE ar.RuleID = ?`,
            [result.insertId]
        );

        res.status(201).json(newRule[0]);
    } catch (error) {
        console.error('Error creating alert rule:', error);
        res.status(500).json({ error: 'Failed to create alert rule' });
    }
};

const updateAlertRule = async (req, res) => {
    try {
        const { daysBeforeRenewal, isActive } = req.body;

        const [result] = await pool.query(
            `UPDATE Alert_Rules 
             SET DaysBeforeRenewal = ?, IsActive = ? 
             WHERE RuleID = ?`,
            [daysBeforeRenewal, isActive, req.params.ruleId]
        );

        if (result.affectedRows === 0) {
            return res.status(404).json({ error: 'Alert rule not found' });
        }

        const [updated] = await pool.query(
            `SELECT ar.*, s.PlatformName 
             FROM Alert_Rules ar 
             JOIN Subscriptions s ON ar.SubID = s.SubID 
             WHERE ar.RuleID = ?`,
            [req.params.ruleId]
        );

        res.json(updated[0]);
    } catch (error) {
        console.error('Error updating alert rule:', error);
        res.status(500).json({ error: 'Failed to update alert rule' });
    }
};

const deleteAlertRule = async (req, res) => {
    try {
        const [result] = await pool.query(
            `DELETE ar FROM Alert_Rules ar 
             JOIN Subscriptions s ON ar.SubID = s.SubID 
             WHERE ar.RuleID = ? AND s.UserID = ?`,
            [req.params.ruleId, req.user.userId]
        );

        if (result.affectedRows === 0) {
            return res.status(404).json({ error: 'Alert rule not found' });
        }

        res.json({ message: 'Alert rule deleted successfully' });
    } catch (error) {
        console.error('Error deleting alert rule:', error);
        res.status(500).json({ error: 'Failed to delete alert rule' });
    }
};

module.exports = {
    getAlertRules,
    createAlertRule,
    updateAlertRule,
    deleteAlertRule
};
