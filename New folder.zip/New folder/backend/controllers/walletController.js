const pool = require('../config/database');

const getBalance = async (userId) => {
    const [rows] = await pool.query('SELECT WalletBalance FROM Users WHERE UserID = ?', [userId]);
    return rows.length ? parseFloat(rows[0].WalletBalance) : 0;
};

const recordTransaction = async (userId, type, amount, description, subId = null) => {
    await pool.query(
        'INSERT INTO Transactions (UserID, Type, Amount, Description, SubID) VALUES (?, ?, ?, ?, ?)',
        [userId, type, amount, description, subId]
    );
};

const advanceRenewalDate = (dateStr, billingCycle) => {
    const d = new Date(dateStr);
    if (billingCycle === 'Monthly') d.setMonth(d.getMonth() + 1);
    else if (billingCycle === 'Quarterly') d.setMonth(d.getMonth() + 3);
    else if (billingCycle === 'Annual') d.setFullYear(d.getFullYear() + 1);
    return d.toISOString().split('T')[0];
};

// Auto-pay active subscriptions whose renewal date has arrived.
// Balance is allowed to go negative (flagged for the UI to warn about).
// Only charges subscriptions with AutoRenew = true.
const processDuePayments = async (userId) => {
    const [due] = await pool.query(
        `SELECT * FROM Subscriptions
         WHERE UserID = ? AND Status = 'Active' AND AutoRenew = 1 AND NextRenewalDate <= CURDATE()`,
        [userId]
    );

    for (const sub of due) {
        const cost = parseFloat(sub.Cost);
        await pool.query('UPDATE Users SET WalletBalance = WalletBalance - ? WHERE UserID = ?', [cost, userId]);
        await recordTransaction(userId, 'debit', cost, `Auto-renewal: ${sub.PlatformName}`, sub.SubID);

        // Move renewal date forward past today (charge once per cycle)
        let next = advanceRenewalDate(sub.NextRenewalDate, sub.BillingCycle);
        const today = new Date().toISOString().split('T')[0];
        while (next <= today) {
            next = advanceRenewalDate(next, sub.BillingCycle);
        }
        await pool.query('UPDATE Subscriptions SET NextRenewalDate = ? WHERE SubID = ?', [next, sub.SubID]);
    }
};

const getWallet = async (req, res) => {
    try {
        await processDuePayments(req.user.userId);

        const balance = await getBalance(req.user.userId);

        const [transactions] = await pool.query(
            `SELECT t.*, s.PlatformName
             FROM Transactions t
             LEFT JOIN Subscriptions s ON t.SubID = s.SubID
             WHERE t.UserID = ?
               AND YEAR(t.CreatedAt) = YEAR(CURDATE())
               AND MONTH(t.CreatedAt) = MONTH(CURDATE())
             ORDER BY t.CreatedAt DESC`,
            [req.user.userId]
        );

        res.json({
            balance,
            negativeBalance: balance < 0,
            transactions
        });
    } catch (error) {
        console.error('Wallet fetch error:', error);
        res.status(500).json({ error: 'Failed to fetch wallet' });
    }
};

const addFunds = async (req, res) => {
    try {
        const { amount, paymentMethodId, cvv } = req.body;
        const value = parseFloat(amount);

        if (!value || value <= 0) {
            return res.status(400).json({ error: 'Enter a valid amount' });
        }

        let methodLabel = 'Wallet';
        if (paymentMethodId) {
            const [methods] = await pool.query(
                'SELECT * FROM Payment_Methods WHERE MethodID = ? AND UserID = ?',
                [paymentMethodId, req.user.userId]
            );
            if (methods.length === 0) {
                return res.status(404).json({ error: 'Payment method not found' });
            }
            const m = methods[0];
            methodLabel = m.PaymentType === 'upi' ? `UPI (${m.UPIID})` : `${m.Provider} ****${m.CardLast4}`;

            if (m.PaymentType !== 'upi' && (!cvv || !/^\d{3,4}$/.test(String(cvv)))) {
                return res.status(400).json({ error: 'CVV is required for card payments' });
            }
        }

        await pool.query('UPDATE Users SET WalletBalance = WalletBalance + ? WHERE UserID = ?', [value, req.user.userId]);
        await recordTransaction(req.user.userId, 'credit', value, `Funds added via ${methodLabel}`);

        const balance = await getBalance(req.user.userId);
        res.json({ balance, message: 'Funds added successfully' });
    } catch (error) {
        console.error('Add funds error:', error);
        res.status(500).json({ error: 'Failed to add funds' });
    }
};

const paySubscription = async (req, res) => {
    try {
        const { subId } = req.body;

        const [subs] = await pool.query(
            'SELECT * FROM Subscriptions WHERE SubID = ? AND UserID = ?',
            [subId, req.user.userId]
        );
        if (subs.length === 0) {
            return res.status(404).json({ error: 'Subscription not found' });
        }

        const sub = subs[0];
        if (sub.Status !== 'Active') {
            return res.status(400).json({ error: 'Subscription must be active to be paid' });
        }

        const amount = parseFloat(sub.Cost);
        await pool.query('UPDATE Users SET WalletBalance = WalletBalance - ? WHERE UserID = ?', [amount, req.user.userId]);
        await recordTransaction(req.user.userId, 'debit', amount, `Payment for ${sub.PlatformName}`, sub.SubID);

        const balance = await getBalance(req.user.userId);
        const wentNegative = balance < 0;
        res.json({
            balance,
            wentNegative,
            message: wentNegative
                ? `Payment successful — your wallet balance is now negative (₹${balance.toFixed(2)}). Please add funds.`
                : `Paid ₹${amount.toFixed(2)} for ${sub.PlatformName}`
        });
    } catch (error) {
        console.error('Pay subscription error:', error);
        res.status(500).json({ error: 'Failed to process payment' });
    }
};

const payQr = async (req, res) => {
    try {
        const { upiId, amount, note } = req.body;
        const value = parseFloat(amount);

        if (!upiId || !upiId.trim()) {
            return res.status(400).json({ error: 'UPI ID is required' });
        }
        if (!value || value <= 0) {
            return res.status(400).json({ error: 'Enter a valid amount' });
        }

        await pool.query('UPDATE Users SET WalletBalance = WalletBalance - ? WHERE UserID = ?', [value, req.user.userId]);
        await recordTransaction(req.user.userId, 'debit', value, note || `QR payment to ${upiId.trim()}`);

        const balance = await getBalance(req.user.userId);
        const wentNegative = balance < 0;
        res.json({
            balance,
            wentNegative,
            message: wentNegative
                ? `Payment successful — your wallet balance is now negative (₹${balance.toFixed(2)}). Please add funds.`
                : `Paid ₹${value.toFixed(2)} to ${upiId.trim()}`
        });
    } catch (error) {
        console.error('QR payment error:', error);
        res.status(500).json({ error: 'Failed to process payment' });
    }
};

module.exports = { getWallet, addFunds, paySubscription, payQr, processDuePayments };
