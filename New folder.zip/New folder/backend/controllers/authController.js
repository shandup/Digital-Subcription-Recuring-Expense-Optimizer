const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const pool = require('../config/database');

const register = async (req, res) => {
    try {
        const { name, email, password } = req.body;

        // Check if user exists
        const [existing] = await pool.query(
            'SELECT * FROM Users WHERE Email = ?',
            [email]
        );

        if (existing.length > 0) {
            return res.status(400).json({ error: 'User already exists' });
        }

        // Hash password
        const passwordHash = await bcrypt.hash(password, 10);

        // Insert user
        const [result] = await pool.query(
            'INSERT INTO Users (Name, Email, PasswordHash) VALUES (?, ?, ?)',
            [name, email, passwordHash]
        );

        // Generate token
        const token = jwt.sign(
            { userId: result.insertId, email },
            process.env.JWT_SECRET || 'your-secret-key',
            { expiresIn: '24h' }
        );

        res.status(201).json({
            token,
            user: { id: result.insertId, name, email }
        });
    } catch (error) {
        console.error('Registration error:', error);
        res.status(500).json({ error: 'Registration failed' });
    }
};

const login = async (req, res) => {
    try {
        const { email, password } = req.body;

        // Find user
        const [users] = await pool.query(
            'SELECT * FROM Users WHERE Email = ?',
            [email]
        );

        if (users.length === 0) {
            return res.status(401).json({ error: 'Invalid credentials' });
        }

        const user = users[0];

        // Check password
        const validPassword = await bcrypt.compare(password, user.PasswordHash);
        if (!validPassword) {
            return res.status(401).json({ error: 'Invalid credentials' });
        }

        // Generate token
        const token = jwt.sign(
            { userId: user.UserID, email: user.Email },
            process.env.JWT_SECRET || 'your-secret-key',
            { expiresIn: '24h' }
        );

        res.json({
            token,
            user: { id: user.UserID, name: user.Name, email: user.Email }
        });
    } catch (error) {
        console.error('Login error:', error);
        res.status(500).json({ error: 'Login failed' });
    }
};

const getProfile = async (req, res) => {
    try {
        const [users] = await pool.query(
            'SELECT UserID, Name, Email, CreatedAt, ProfilePhoto FROM Users WHERE UserID = ?',
            [req.user.userId]
        );

        if (users.length === 0) {
            return res.status(404).json({ error: 'User not found' });
        }

        const user = users[0];
        res.json({
            id: user.UserID,
            name: user.Name,
            email: user.Email,
            createdAt: user.CreatedAt,
            photo: user.ProfilePhoto
        });
    } catch (error) {
        console.error('Profile error:', error);
        res.status(500).json({ error: 'Failed to fetch profile' });
    }
};

const updateProfile = async (req, res) => {
    try {
        const { name } = req.body;

        if (!name || !name.trim()) {
            return res.status(400).json({ error: 'Name is required' });
        }

        await pool.query(
            'UPDATE Users SET Name = ? WHERE UserID = ?',
            [name.trim(), req.user.userId]
        );

        const [users] = await pool.query(
            'SELECT UserID, Name, Email, ProfilePhoto FROM Users WHERE UserID = ?',
            [req.user.userId]
        );

        const user = users[0];
        res.json({
            user: {
                id: user.UserID,
                name: user.Name,
                email: user.Email,
                photo: user.ProfilePhoto
            }
        });
    } catch (error) {
        console.error('Update profile error:', error);
        res.status(500).json({ error: 'Failed to update profile' });
    }
};

const updatePassword = async (req, res) => {
    try {
        const { currentPassword, newPassword } = req.body;

        if (!currentPassword || !newPassword) {
            return res.status(400).json({ error: 'Current and new password are required' });
        }

        if (newPassword.length < 6) {
            return res.status(400).json({ error: 'New password must be at least 6 characters' });
        }

        const [users] = await pool.query(
            'SELECT PasswordHash FROM Users WHERE UserID = ?',
            [req.user.userId]
        );

        if (users.length === 0) {
            return res.status(404).json({ error: 'User not found' });
        }

        const validPassword = await bcrypt.compare(currentPassword, users[0].PasswordHash);
        if (!validPassword) {
            return res.status(400).json({ error: 'Current password is incorrect' });
        }

        const passwordHash = await bcrypt.hash(newPassword, 10);
        await pool.query(
            'UPDATE Users SET PasswordHash = ? WHERE UserID = ?',
            [passwordHash, req.user.userId]
        );

        res.json({ message: 'Password updated successfully' });
    } catch (error) {
        console.error('Update password error:', error);
        res.status(500).json({ error: 'Failed to update password' });
    }
};

const updatePhoto = async (req, res) => {
    try {
        const { photo } = req.body;

        if (!photo || typeof photo !== 'string' || !photo.startsWith('data:image/')) {
            return res.status(400).json({ error: 'A valid image is required' });
        }

        if (photo.length > 2 * 1024 * 1024) {
            return res.status(400).json({ error: 'Image is too large (max ~1.5 MB)' });
        }

        await pool.query(
            'UPDATE Users SET ProfilePhoto = ? WHERE UserID = ?',
            [photo, req.user.userId]
        );

        res.json({ message: 'Profile photo updated successfully' });
    } catch (error) {
        console.error('Update photo error:', error);
        res.status(500).json({ error: 'Failed to update profile photo' });
    }
};

const resetPassword = async (req, res) => {
    try {
        const { email, newPassword } = req.body;

        if (!email || !newPassword) {
            return res.status(400).json({ error: 'Email and new password are required' });
        }
        if (newPassword.length < 6) {
            return res.status(400).json({ error: 'Password must be at least 6 characters' });
        }

        const [users] = await pool.query('SELECT UserID FROM Users WHERE Email = ?', [email]);
        if (users.length === 0) {
            return res.status(404).json({ error: 'No account found with this email' });
        }

        const passwordHash = await bcrypt.hash(newPassword, 10);
        await pool.query('UPDATE Users SET PasswordHash = ? WHERE UserID = ?', [passwordHash, users[0].UserID]);

        res.json({ message: 'Password reset successfully. You can now log in.' });
    } catch (error) {
        console.error('Reset password error:', error);
        res.status(500).json({ error: 'Failed to reset password' });
    }
};

module.exports = { register, login, getProfile, updateProfile, updatePassword, updatePhoto, resetPassword };
