# Digital Subscription & Recurring Expense Optimizer
## DBMS Mini Project Documentation

---

## Project Overview

This application is a comprehensive subscription management system designed to help users track recurring software/service payments, receive alerts before renewals, log service usage, and identify underutilized subscriptions to save money.

### Objectives

1. **Track Recurring Payments**: Monitor all subscription-based services and their billing cycles
2. **Renewal Alerts**: Configure custom alerts before subscription renewals
3. **Usage Logging**: Track when and how services are used
4. **Cost Optimization**: Identify high-risk, underutilized subscriptions
5. **Data Integrity**: Ensure consistent and reliable data through proper database design

---

## Database Design

### Entity-Relationship Model

```
Users (1) ----< (N) Payment_Methods
  |                      |
  |                      |
  |                      v
  |            Subscriptions (1) ----< (N) Alert_Rules
  |                      |
  |                      |
  |                      v
  |            Usage_Logs (N)
```

### Schema Details (3NF Normalized)

#### 1. Users Table

Stores user account information with authentication credentials.

```sql
CREATE TABLE Users (
    UserID INT AUTO_INCREMENT PRIMARY KEY,
    Name VARCHAR(100) NOT NULL,
    Email VARCHAR(150) UNIQUE NOT NULL,
    PasswordHash VARCHAR(255) NOT NULL,
    CreatedAt DATETIME DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_email (Email)
);
```

**Constraints:**
- `UserID`: Primary Key, Auto-increment
- `Email`: UNIQUE constraint to prevent duplicate emails
- `PasswordHash`: Stores bcrypt-hashed passwords (never plain text)
- `CreatedAt`: Defaults to current timestamp
- `idx_email`: Index for faster email lookups during login

**Normalization (3NF):**
- All non-key attributes depend only on the primary key
- No transitive dependencies
- Atomic values (each field holds single value)

---

#### 2. Payment_Methods Table

Stores payment methods linked to users.

```sql
CREATE TABLE Payment_Methods (
    MethodID INT AUTO_INCREMENT PRIMARY KEY,
    UserID INT NOT NULL,
    Provider VARCHAR(50),
    CardLast4 CHAR(4),
    ExpiryDate DATE,
    CONSTRAINT fk_payment_user FOREIGN KEY (UserID)
        REFERENCES Users(UserID)
        ON DELETE CASCADE,
    CONSTRAINT chk_cardlast4 CHECK (CardLast4 REGEXP '^[0-9]{4}$' OR CardLast4 IS NULL)
);
```

**Constraints:**
- `MethodID`: Primary Key, Auto-increment
- `UserID`: Foreign Key to Users.UserID
- `fk_payment_user`: ON DELETE CASCADE - when user is deleted, all their payment methods are deleted
- `chk_cardlast4`: CHECK constraint ensures exactly 4 digits or NULL

**Normalization (3NF):**
- No partial dependencies (all non-key attributes depend on full primary key)
- No transitive dependencies

---

#### 3. Subscriptions Table

Core table storing subscription information.

```sql
CREATE TABLE Subscriptions (
    SubID INT AUTO_INCREMENT PRIMARY KEY,
    UserID INT NOT NULL,
    MethodID INT,
    PlatformName VARCHAR(100) NOT NULL,
    PlanName VARCHAR(100),
    Cost DECIMAL(10,2) NOT NULL,
    BillingCycle ENUM('Monthly', 'Quarterly', 'Annual') NOT NULL,
    StartDate DATE NOT NULL,
    NextRenewalDate DATE NOT NULL,
    Status ENUM('Active', 'Paused', 'Cancelled') DEFAULT 'Active',
    CONSTRAINT fk_subscription_user FOREIGN KEY (UserID)
        REFERENCES Users(UserID)
        ON DELETE CASCADE,
    CONSTRAINT fk_subscription_payment FOREIGN KEY (MethodID)
        REFERENCES Payment_Methods(MethodID)
        ON DELETE SET NULL,
    CONSTRAINT chk_cost CHECK (Cost >= 0),
    INDEX idx_user_status (UserID, Status),
    INDEX idx_next_renewal (NextRenewalDate)
);
```

**Constraints:**
- `SubID`: Primary Key, Auto-increment
- `UserID`: Foreign Key to Users.UserID with CASCADE delete
- `MethodID`: Foreign Key to Payment_Methods.MethodID with SET NULL (allows subscriptions without payment methods)
- `chk_cost`: CHECK constraint ensures non-negative cost
- `BillingCycle`: ENUM restricts to valid values
- `Status`: ENUM with default 'Active'
- `idx_user_status`: Composite index for faster user-specific status queries
- `idx_next_renewal`: Index for renewal date queries

**Normalization (3NF):**
- MethodID can be NULL (allows subscriptions without payment methods)
- No partial or transitive dependencies

---

#### 4. Usage_Logs Table

Tracks usage instances for each subscription.

```sql
CREATE TABLE Usage_Logs (
    LogID INT AUTO_INCREMENT PRIMARY KEY,
    SubID INT NOT NULL,
    DateAccessed DATE NOT NULL,
    ActionType VARCHAR(50) NOT NULL,
    CONSTRAINT fk_usage_subscription FOREIGN KEY (SubID)
        REFERENCES Subscriptions(SubID)
        ON DELETE CASCADE,
    INDEX idx_sub_date (SubID, DateAccessed)
);
```

**Constraints:**
- `LogID`: Primary Key, Auto-increment
- `SubID`: Foreign Key to Subscriptions.SubID with CASCADE delete
- `idx_sub_date`: Composite index for efficient date-range queries

**Normalization (3NF):**
- All attributes depend only on LogID
- No transitive dependencies

---

#### 5. Alert_Rules Table

Configures alert notifications for subscription renewals.

```sql
CREATE TABLE Alert_Rules (
    RuleID INT AUTO_INCREMENT PRIMARY KEY,
    SubID INT NOT NULL,
    DaysBeforeRenewal INT NOT NULL,
    IsActive BOOLEAN DEFAULT TRUE,
    CONSTRAINT fk_alert_subscription FOREIGN KEY (SubID)
        REFERENCES Subscriptions(SubID)
        ON DELETE CASCADE,
    CONSTRAINT chk_days_before CHECK (DaysBeforeRenewal BETWEEN 1 AND 30)
);
```

**Constraints:**
- `RuleID`: Primary Key, Auto-increment
- `SubID`: Foreign Key to Subscriptions.SubID with CASCADE delete
- `chk_days_before`: CHECK constraint ensures value between 1-30 days
- `IsActive`: BOOLEAN with default TRUE

**Normalization (3NF):**
- All attributes depend only on RuleID
- No transitive dependencies

---

### Referential Integrity

All foreign key relationships maintain referential integrity:

1. **Users → Payment_Methods**: CASCADE delete
2. **Users → Subscriptions**: CASCADE delete
3. **Payment_Methods → Subscriptions**: SET NULL (allows orphaned subscriptions)
4. **Subscriptions → Usage_Logs**: CASCADE delete
5. **Subscriptions → Alert_Rules**: CASCADE delete

This ensures:
- No orphaned records (except intentional SET NULL)
- Consistent data relationships
- Automatic cleanup on deletion

---

## Core Features Implementation

### 1. User Authentication

**Technology:** JWT (JSON Web Tokens) + bcrypt

**Flow:**
1. User registers with email and password
2. Password is hashed using bcrypt (10 salt rounds)
3. User record is created in Users table
4. JWT token is generated containing userId and email
5. Token is stored in localStorage and sent with each request

**Security Measures:**
- Passwords never stored in plain text
- JWT tokens expire after 24 hours
- Middleware validates token on protected routes
- Row-level security: users can only access their own data

**API Endpoints:**
- `POST /api/auth/register` - Register new user
- `POST /api/auth/login` - Authenticate user
- `GET /api/auth/profile` - Get user profile (protected)

---

### 2. Subscription Creation with Database Transaction

**Transaction Flow:**

```javascript
await connection.beginTransaction();

try {
    // 1. Insert subscription
    const [result] = await connection.query(
        'INSERT INTO Subscriptions (...) VALUES (...)',
        [...]
    );

    // 2. Insert default alert rule
    await connection.query(
        'INSERT INTO Alert_Rules (...) VALUES (...)',
        [...]
    );

    // 3. Commit if both succeed
    await connection.commit();
} catch (error) {
    // 4. Rollback if any step fails
    await connection.rollback();
}
```

**Why Transactions Matter:**
- **Atomicity**: Both subscription and alert rule must be created together
- **Consistency**: Maintains data integrity (every subscription has an alert rule)
- **Isolation**: Other transactions don't see partial state
- **Durability**: Once committed, changes persist even if system crashes

**Automatic Next Renewal Calculation:**

```javascript
const calculateNextRenewalDate = (startDate, billingCycle) => {
    const start = new Date(startDate);
    const nextRenewal = new Date(start);

    switch (billingCycle) {
        case 'Monthly':
            nextRenewal.setMonth(nextRenewal.getMonth() + 1);
            break;
        case 'Quarterly':
            nextRenewal.setMonth(nextRenewal.getMonth() + 3);
            break;
        case 'Annual':
            nextRenewal.setFullYear(nextRenewal.getFullYear() + 1);
            break;
    }

    return nextRenewal.toISOString().split('T')[0];
};
```

---

### 3. Usage Logging

**Purpose:** Track when services are actually used to identify underutilized subscriptions.

**Features:**
- Log usage instances with date and action type
- View usage history per subscription
- Delete incorrect log entries
- Used in analytics to calculate "days since last use"

**API Endpoints:**
- `GET /api/usage/:subId` - Get usage logs for subscription
- `POST /api/usage` - Create usage log
- `DELETE /api/usage/:logId` - Delete usage log

---

### 4. Status Updates with Confirmation

**Subscription Status Options:**
- **Active**: Currently being paid and used
- **Paused**: Temporarily suspended (no payments, but not cancelled)
- **Cancelled**: Terminated subscription

**Frontend Confirmation:**
Modal dialog appears before destructive actions (delete/cancel):

```javascript
const confirmDelete = (subId) => {
    setSubscriptionToDelete(subId);
    setShowDeleteModal(true);
};

// Modal shows:
// "Are you sure you want to delete this subscription?"
// "This action cannot be undone."
```

This prevents accidental deletions and improves user experience.

---

### 5. Advanced Analytics Query

**The Waste Report Query:**

```sql
SELECT
    s.SubID,
    s.PlatformName,
    s.PlanName,
    s.Cost,
    s.BillingCycle,
    s.NextRenewalDate,
    MAX(u.DateAccessed) AS LastUsedDate,
    COALESCE(DATEDIFF(CURRENT_DATE, MAX(u.DateAccessed)), 999) AS DaysSinceLastUse,
    CASE
        WHEN DATEDIFF(CURRENT_DATE, MAX(u.DateAccessed)) > 30
        OR MAX(u.DateAccessed) IS NULL
        THEN 'High Risk - Consider Canceling'
        ELSE 'Active Engagement'
    END AS WasteRecommendation
FROM Subscriptions s
LEFT JOIN Usage_Logs u ON s.SubID = u.SubID
WHERE s.UserID = ? AND s.Status = 'Active'
GROUP BY s.SubID, s.PlatformName, s.PlanName, s.Cost, s.BillingCycle, s.NextRenewalDate
ORDER BY DaysSinceLastUse DESC;
```

**Query Breakdown:**

1. **LEFT JOIN**: Includes subscriptions without any usage logs
2. **MAX(u.DateAccessed)**: Finds the most recent usage date
3. **COALESCE(..., 999)**: Returns 999 if no usage exists (never used)
4. **DATEDIFF**: Calculates days between current date and last use
5. **CASE**: Categorizes as "High Risk" if unused for >30 days
6. **GROUP BY**: Aggregates usage data per subscription
7. **ORDER BY**: Shows highest-risk subscriptions first

**Analytics Metrics:**
- Total monthly cost (normalized to monthly for all cycles)
- High-risk subscription count
- Potential savings (cost of high-risk subscriptions)
- Days since last use per subscription
- Risk recommendations

---

## API Architecture

### RESTful Design

All endpoints follow REST principles:

| Method | Endpoint | Description | Protected |
|--------|----------|-------------|-----------|
| POST | /api/auth/register | Register user | No |
| POST | /api/auth/login | Login user | No |
| GET | /api/auth/profile | Get profile | Yes |
| GET | /api/payments | Get payment methods | Yes |
| POST | /api/payments | Create payment method | Yes |
| PUT | /api/payments/:id | Update payment method | Yes |
| DELETE | /api/payments/:id | Delete payment method | Yes |
| GET | /api/subscriptions | Get subscriptions | Yes |
| POST | /api/subscriptions | Create subscription | Yes |
| PUT | /api/subscriptions/:id | Update subscription | Yes |
| DELETE | /api/subscriptions/:id | Delete subscription | Yes |
| GET | /api/usage/:subId | Get usage logs | Yes |
| POST | /api/usage | Create usage log | Yes |
| DELETE | /api/usage/:logId | Delete usage log | Yes |
| GET | /api/alerts/:subId | Get alert rules | Yes |
| POST | /api/alerts | Create alert rule | Yes |
| PUT | /api/alerts/:ruleId | Update alert rule | Yes |
| DELETE | /api/alerts/:ruleId | Delete alert rule | Yes |
| GET | /api/analytics/waste-report | Get waste report | Yes |
| GET | /api/analytics/dashboard | Get dashboard data | Yes |

### Authentication Middleware

```javascript
const auth = (req, res, next) => {
    try {
        const token = req.header('Authorization')?.replace('Bearer ', '');

        if (!token) {
            return res.status(401).json({ error: 'No authentication token' });
        }

        const decoded = jwt.verify(token, process.env.JWT_SECRET);
        req.user = decoded;
        next();
    } catch (error) {
        res.status(401).json({ error: 'Token is not valid' });
    }
};
```

### Input Validation

Using `express-validator` for server-side validation:

```javascript
const register = [
    body('name').trim().notEmpty().withMessage('Name is required'),
    body('email').isEmail().withMessage('Valid email is required'),
    body('password').isLength({ min: 6 }).withMessage('Password must be at least 6 characters'),
    async (req, res) => {
        const errors = validationResult(req);
        if (!errors.isEmpty()) {
            return res.status(400).json({ errors: errors.array() });
        }
        // ... registration logic
    }
];
```

---

## Frontend Architecture

### Technology Stack

- **React 18**: UI library with hooks
- **React Router v6**: Client-side routing
- **Axios**: HTTP client for API calls
- **Tailwind CSS**: Utility-first CSS framework

### Component Structure

```
App.js (Main router)
├── Navigation (Navbar)
├── Login
├── Register
├── Dashboard
├── Subscriptions
│   └── SubscriptionForm (Add/Edit)
├── UsageLogs
├── Analytics
└── PaymentMethods
```

### State Management

- **Auth Context**: Global authentication state (user, token, login/logout)
- **Local State**: Component-specific state using `useState`
- **Effects**: Data fetching using `useEffect`

### API Integration

```javascript
const token = localStorage.getItem('token');
const response = await axios.get('/api/subscriptions', {
    headers: { Authorization: `Bearer ${token}` }
});
```

---

## Security Features

### 1. Password Security
- Bcrypt hashing with 10 salt rounds
- Minimum 6 character password requirement
- Passwords never logged or exposed

### 2. JWT Authentication
- Stateless token-based authentication
- 24-hour token expiration
- Token stored in localStorage (could be improved with httpOnly cookies)

### 3. SQL Injection Prevention
- All queries use parameterized statements
- Never concatenate user input into SQL
- MySQL2 library handles escaping

### 4. Row-Level Security
- All queries include `WHERE UserID = ?`
- Middleware extracts userId from JWT
- Users can only access their own data

### 5. Input Validation
- Server-side validation on all inputs
- Email format validation
- Numeric range checks
- ENUM value validation

---

## Performance Optimizations

### Database Indexes

1. **idx_email** on Users.Email - Faster login lookups
2. **idx_user_status** on Subscriptions(UserID, Status) - Faster user-specific queries
3. **idx_next_renewal** on Subscriptions.NextRenewalDate - Faster renewal date queries
4. **idx_sub_date** on Usage_Logs(SubID, DateAccessed) - Faster date-range queries

### Connection Pooling

```javascript
const pool = mysql.createPool({
    connectionLimit: 10,
    waitForConnections: true,
    queueLimit: 0
});
```

- Reuses database connections
- Reduces connection overhead
- Handles concurrent requests efficiently

---

## Testing Strategy

### Manual Testing Checklist

- [ ] User registration with valid/invalid data
- [ ] User login with correct/incorrect credentials
- [ ] Adding payment methods
- [ ] Creating subscriptions with all billing cycles
- [ ] Automatic next renewal date calculation
- [ ] Logging usage for subscriptions
- [ ] Viewing usage history
- [ ] Updating subscription status
- [ ] Deleting subscriptions (with confirmation)
- [ ] Viewing dashboard statistics
- [ ] Analytics report generation
- [ ] High-risk subscription identification
- [ ] Alert rule creation and management

### Sample Data

The `seed.sql` includes:
- 3 test users
- 4 payment methods
- 14 subscriptions (various statuses and cycles)
- 25+ usage logs (recent and old to test analytics)
- 13 alert rules

This provides a realistic dataset for testing the analytics query.

---

## Future Enhancements

### Potential Improvements

1. **Email Notifications**: Send actual email alerts before renewals
2. **Recurring Jobs**: Background jobs to check renewal dates and send alerts
3. **Payment Integration**: Actual payment method integration (Stripe, etc.)
4. **Charts/Graphs**: Visual analytics with charts
5. **Export Data**: CSV/PDF export of reports
6. **Multi-user Teams**: Shared subscriptions for teams/families
7. **Budget Limits**: Set monthly budget and alert when exceeded
8. **Mobile App**: React Native mobile application
9. **Dark Mode**: UI theme toggle
10. **Data Import**: Bulk import from other services

---

## Conclusion

This project demonstrates:

1. **Database Design**: Proper normalization, constraints, and relationships
2. **Transaction Management**: Ensuring data integrity with ACID properties
3. **Advanced SQL**: Complex queries with JOINs, GROUP BY, and CASE statements
4. **Security**: Authentication, authorization, and input validation
5. **Full-Stack Development**: End-to-end application from database to UI
6. **User Experience**: Intuitive interface with confirmations and feedback

The application successfully addresses the core problem of subscription management while showcasing best practices in database design and web development.

---

## Technical Specifications

**Backend:**
- Node.js v14+
- Express.js v4.18
- MySQL v5.7+
- JWT v9.0
- Bcryptjs v2.4

**Frontend:**
- React v18.2
- React Router v6.20
- Axios v1.6
- Tailwind CSS v3.3

**Database:**
- MySQL 5.7+
- InnoDB engine
- UTF-8 character set
- 5 tables, 12 indexes, 11 constraints

---

## Project Files Summary

```
Backend Files (17):
- server.js: Express server setup
- config/database.js: MySQL connection pool
- middleware/auth.js: JWT authentication
- controllers/ (6 files): Business logic for each resource
- routes/ (6 files): API route definitions

Frontend Files (13):
- client/src/App.js: Main router and auth context
- client/src/index.js: Entry point
- client/src/index.css: Tailwind imports
- client/src/components/ (8 files): React components
- client/tailwind.config.js: Tailwind configuration
- client/postcss.config.js: PostCSS configuration

Database Files (2):
- database/schema.sql: Table definitions
- database/seed.sql: Sample data

Configuration Files (3):
- package.json: Backend dependencies
- client/package.json: Frontend dependencies
- .env.example: Environment template

Documentation Files (3):
- README.md: Project overview
- SETUP.md: Installation guide
- PROJECT_DOCUMENTATION.md: This file
```

---

**Project Completed: Digital Subscription & Recurring Expense Optimizer**
**Course: DBMS Mini Project**
**Date: 2026-10-07**
