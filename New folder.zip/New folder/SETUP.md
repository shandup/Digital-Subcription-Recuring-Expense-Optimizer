# Setup and Installation Guide

This guide will help you set up the Digital Subscription & Recurring Expense Optimizer application on your local machine.

## Prerequisites

Before you begin, ensure you have the following installed:

- **Node.js** (v14 or higher) - [Download here](https://nodejs.org/)
- **MySQL** (v5.7 or higher) - [Download here](https://dev.mysql.com/downloads/mysql/)
- **npm** (comes with Node.js) or **yarn**

---

## Step 1: Database Setup

### 1.1 Install MySQL

If you don't have MySQL installed:
- Download and install MySQL from the official website
- During installation, set a root password (remember this password)
- Start the MySQL service

### 1.2 Create the Database

Open MySQL Command Line Client or use a tool like MySQL Workbench:

```sql
-- Login to MySQL
mysql -u root -p

-- Create the database
CREATE DATABASE subscription_optimizer;

-- Verify database creation
SHOW DATABASES;

-- Exit MySQL
exit;
```

### 1.3 Run the Schema Script

This creates all the required tables with proper constraints and relationships.

**Using Command Line:**
```bash
# Navigate to the project directory
cd D:\Amrita\Sem_3\DBMS\Project

# Run the schema script
mysql -u root -p subscription_optimizer < database/schema.sql
```

**Using MySQL Workbench:**
1. Open MySQL Workbench
2. Connect to your MySQL server
3. Select the `subscription_optimizer` database
4. File > Run SQL Script
5. Select `database/schema.sql`
6. Click Run

### 1.4 (Optional) Run the Seed Script

This populates the database with sample data for testing.

```bash
mysql -u root -p subscription_optimizer < database/seed.sql
```

---

## Step 2: Environment Configuration

### 2.1 Create .env File

Copy the example environment file:

```bash
# In the project root directory
copy .env.example .env
```

Or create a new `.env` file manually in the project root.

### 2.2 Configure Environment Variables

Open `.env` and update the following values:

```env
# Database Configuration
DB_HOST=localhost
DB_USER=root
DB_PASSWORD=your_mysql_password_here
DB_NAME=subscription_optimizer
DB_PORT=3306

# JWT Secret (change this to a random secure string)
JWT_SECRET=your_super_secret_jwt_key_change_this_in_production

# Server Configuration
PORT=5000
NODE_ENV=development
```

**Important:**
- Replace `your_mysql_password_here` with your actual MySQL root password
- Generate a secure JWT secret (you can use a random string generator)
- Never commit `.env` to version control

---

## Step 3: Install Backend Dependencies

```bash
# In the project root directory
cd D:\Amrita\Sem_3\DBMS\Project
npm install
```

This will install:
- express - Web framework
- mysql2 - MySQL driver
- bcryptjs - Password hashing
- jsonwebtoken - JWT authentication
- cors - Cross-origin resource sharing
- dotenv - Environment variable management
- express-validator - Input validation
- nodemon - Development server (auto-restart)

---

## Step 4: Install Frontend Dependencies

```bash
# Navigate to the client directory
cd client

# Install dependencies
npm install
```

This will install:
- react - UI library
- react-dom - React DOM renderer
- react-router-dom - Routing
- axios - HTTP client
- react-scripts - React build tool
- tailwindcss - CSS framework
- autoprefixer - CSS post-processor
- postcss - CSS processor

---

## Step 5: Running the Application

### Development Mode (Recommended for Development)

You need two terminal windows:

**Terminal 1 - Backend Server:**
```bash
cd D:\Amrita\Sem_3\DBMS\Project
npm run dev
```

The backend will start on `http://localhost:5000`

**Terminal 2 - Frontend Server:**
```bash
cd D:\Amrita\Sem_3\DBMS\Project\client
npm start
```

The frontend will open automatically in your browser at `http://localhost:3000`

### Production Mode

**Build the frontend:**
```bash
cd D:\Amrita\Sem_3\DBMS\Project\client
npm run build
```

**Start the backend:**
```bash
cd D:\Amrita\Sem_3\DBMS\Project
npm start
```

The application will be available at `http://localhost:5000`

---

## Step 6: Testing the Application

### 6.1 Register a New User

1. Open `http://localhost:3000` in your browser
2. Click "Register"
3. Fill in the form:
   - Name: Your name
   - Email: A valid email address
   - Password: At least 6 characters
   - Confirm Password: Same as password
4. Click "Register"

### 6.2 Add a Payment Method

1. Navigate to "Payment Methods"
2. Fill in the form:
   - Provider: e.g., "Visa"
   - Card Last 4 Digits: e.g., "4242"
   - Expiry Date: Select a future date
3. Click "Add Payment Method"

### 6.3 Add a Subscription

1. Navigate to "Subscriptions"
2. Click "Add Subscription"
3. Fill in the form:
   - Platform Name: e.g., "Netflix"
   - Plan Name: e.g., "Premium"
   - Cost: e.g., "15.99"
   - Billing Cycle: Select from dropdown
   - Start Date: Select today's date
   - Payment Method: Select the method you added
4. Click "Create Subscription"

### 6.4 Log Usage

1. Navigate to "Usage Logs"
2. Select the subscription you created
3. Fill in:
   - Date Accessed: Today's date
   - Action Type: e.g., "Watched Movie"
4. Click "Log Usage"

### 6.5 View Analytics

1. Navigate to "Analytics"
2. View the waste expense report
3. Check the dashboard for overview statistics

---

## Troubleshooting

### Issue: "Database connection failed"

**Solution:**
1. Verify MySQL is running
2. Check your `.env` file credentials
3. Ensure the database `subscription_optimizer` exists
4. Test the connection manually:
   ```bash
   mysql -u root -p subscription_optimizer
   ```

### Issue: "Port 5000 already in use"

**Solution:**
- Change the PORT in `.env` to a different number (e.g., 5001)
- Or stop the process using port 5000:
  ```bash
  # Windows
  netstat -ano | findstr :5000
  taskkill /PID <PID> /F
  ```

### Issue: "Port 3000 already in use"

**Solution:**
- React will automatically prompt to use a different port
- Or stop the process using port 3000

### Issue: "Module not found" errors

**Solution:**
- Ensure you ran `npm install` in both the root and client directories
- Delete `node_modules` and `package-lock.json` and reinstall:
  ```bash
  # In root directory
  rm -rf node_modules package-lock.json
  npm install

  # In client directory
  rm -rf node_modules package-lock.json
  npm install
  ```

### Issue: "JWT_SECRET not configured"

**Solution:**
- Ensure `.env` file exists in the project root
- Add `JWT_SECRET=your_secret_key` to `.env`
- Restart the server

### Issue: Frontend styling not appearing

**Solution:**
- Ensure Tailwind CSS dependencies are installed
- Check that `index.css` is imported in `index.js`
- Clear browser cache and reload

---

## Database Schema Reference

### Tables:

1. **Users** - User accounts
   - UserID (PK, AUTO_INCREMENT)
   - Name, Email (UNIQUE), PasswordHash, CreatedAt

2. **Payment_Methods** - Payment methods linked to users
   - MethodID (PK, AUTO_INCREMENT)
   - UserID (FK), Provider, CardLast4, ExpiryDate

3. **Subscriptions** - Service subscriptions
   - SubID (PK, AUTO_INCREMENT)
   - UserID (FK), MethodID (FK), PlatformName, PlanName, Cost, BillingCycle, StartDate, NextRenewalDate, Status

4. **Usage_Logs** - Usage tracking
   - LogID (PK, AUTO_INCREMENT)
   - SubID (FK), DateAccessed, ActionType

5. **Alert_Rules** - Alert configurations
   - RuleID (PK, AUTO_INCREMENT)
   - SubID (FK), DaysBeforeRenewal, IsActive

### Key Features:
- Foreign key constraints with CASCADE/SET NULL
- CHECK constraints for data validation
- INDEXes for performance optimization
- 3NF normalized structure

---

## API Testing with Postman/cURL

You can test the API endpoints directly:

### Register User
```bash
curl -X POST http://localhost:5000/api/auth/register \
  -H "Content-Type: application/json" \
  -d '{"name":"John Doe","email":"john@example.com","password":"password123"}'
```

### Login
```bash
curl -X POST http://localhost:5000/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{"email":"john@example.com","password":"password123"}'
```

### Get Subscriptions (requires token)
```bash
curl -X GET http://localhost:5000/api/subscriptions \
  -H "Authorization: Bearer YOUR_JWT_TOKEN"
```

---

## Security Notes

1. **Never commit `.env` file** - It contains sensitive information
2. **Change JWT_SECRET** in production - Use a strong, random string
3. **Use strong passwords** - The app enforces minimum 6 characters
4. **HTTPS in production** - Always use HTTPS for production deployments
5. **Database credentials** - Use a separate database user with limited permissions in production

---

## Next Steps

After successful setup:

1. Explore the dashboard
2. Add your real subscriptions
3. Log usage regularly
4. Review the analytics report monthly
5. Cancel unused subscriptions to save money

---

## Support

If you encounter issues not covered in this guide:

1. Check the console for error messages
2. Verify all prerequisites are installed
3. Ensure MySQL service is running
4. Review the logs in both terminal windows

---

## Project Structure

```
Project/
├── client/                 # React frontend
│   ├── public/
│   ├── src/
│   │   ├── components/     # React components
│   │   ├── App.js          # Main app with routing
│   │   ├── index.js        # Entry point
│   │   └── index.css       # Tailwind CSS imports
│   ├── package.json
│   ├── tailwind.config.js  # Tailwind configuration
│   └── postcss.config.js   # PostCSS configuration
├── config/
│   └── database.js         # MySQL connection pool
├── controllers/            # API controllers
├── database/
│   ├── schema.sql          # Database schema
│   └── seed.sql            # Sample data
├── middleware/
│   └── auth.js             # JWT authentication
├── routes/                 # API routes
├── server.js               # Express server
├── package.json
├── .env                    # Environment variables (create this)
├── .env.example            # Environment template
├── .gitignore
├── README.md
└── SETUP.md                # This file
```

---

## Quick Start Commands

```bash
# Setup database
mysql -u root -p
CREATE DATABASE subscription_optimizer;
exit;
mysql -u root -p subscription_optimizer < database/schema.sql
mysql -u root -p subscription_optimizer < database/seed.sql

# Install dependencies
npm install
cd client
npm install
cd ..

# Run development servers
# Terminal 1
npm run dev

# Terminal 2
cd client
npm start
```

---

**Happy Subscription Managing! 🚀**
