-- Digital Subscription & Recurring Expense Optimizer
-- Seed Data for Testing

-- Note: Passwords are bcrypt hashed. 
-- "password123" -> $2a$10$YourHashHere (these are example hashes)
USE subscription_optimizer;
-- Insert Users
INSERT INTO Users (Name, Email, PasswordHash, CreatedAt) VALUES
('John Doe', 'john.doe@example.com', '$2a$10$X7OrjHKlZqG1LZlZlZlZlZuX7OrjHKlZqG1LZlZlZlZlZlZlZlZl', '2024-01-15 10:00:00'),
('Jane Smith', 'jane.smith@example.com', '$2a$10$X7OrjHKlZqG1LZlZlZlZlZuX7OrjHKlZqG1LZlZlZlZlZlZlZlZlZl', '2024-02-20 14:30:00'),
('Alex Johnson', 'alex.johnson@example.com', '$2a$10$X7OrjHKlZqG1LZlZlZlZlZuX7OrjHKlZqG1LZlZlZlZlZlZlZlZlZl', '2024-03-10 09:15:00');

-- Insert Payment Methods
INSERT INTO Payment_Methods (UserID, Provider, CardLast4, ExpiryDate) VALUES
(1, 'Visa', '4242', '2025-12-31'),
(1, 'Mastercard', '5555', '2026-06-30'),
(2, 'Visa', '1234', '2025-08-15'),
(3, 'American Express', '7890', '2026-03-31');

-- Insert Subscriptions
INSERT INTO Subscriptions (UserID, MethodID, PlatformName, PlanName, Cost, BillingCycle, StartDate, NextRenewalDate, Status) VALUES
-- John Doe's subscriptions
(1, 1, 'Netflix', 'Premium', 15.99, 'Monthly', '2024-01-01', '2025-01-01', 'Active'),
(1, 1, 'Spotify', 'Premium', 9.99, 'Monthly', '2024-02-01', '2025-01-01', 'Active'),
(1, 2, 'Adobe Creative Cloud', 'All Apps', 54.99, 'Monthly', '2024-03-01', '2025-01-01', 'Active'),
(1, 1, 'Netflix', 'Standard', 13.99, 'Monthly', '2024-04-01', '2025-01-01', 'Cancelled'),
(1, 2, 'Microsoft 365', 'Personal', 6.99, 'Monthly', '2024-05-01', '2025-01-01', 'Paused'),

-- Jane Smith's subscriptions
(2, 3, 'Netflix', 'Premium', 15.99, 'Monthly', '2024-01-15', '2025-01-15', 'Active'),
(2, 3, 'Amazon Prime', 'Annual', 139.00, 'Annual', '2024-03-01', '2025-03-01', 'Active'),
(2, 3, 'Disney+', 'Premium', 10.99, 'Monthly', '2024-06-01', '2025-01-01', 'Active'),
(2, 3, 'YouTube Premium', 'Individual', 11.99, 'Monthly', '2024-07-01', '2025-01-01', 'Active'),

-- Alex Johnson's subscriptions
(3, 4, 'Netflix', 'Premium', 15.99, 'Monthly', '2024-02-01', '2025-01-01', 'Active'),
(3, 4, 'Dropbox', 'Plus', 11.99, 'Monthly', '2024-04-01', '2025-01-01', 'Active'),
(3, 4, 'GitHub Pro', 'Individual', 4.00, 'Monthly', '2024-05-01', '2025-01-01', 'Active'),
(3, 4, 'Slack', 'Pro', 8.00, 'Monthly', '2024-06-01', '2025-01-01', 'Active'),
(3, 4, 'Notion', 'Personal', 4.00, 'Monthly', '2024-07-01', '2025-01-01', 'Active');

-- Insert Usage Logs (some recent, some old to test analytics)
INSERT INTO Usage_Logs (SubID, DateAccessed, ActionType) VALUES
-- Netflix (SubID 1) - Recently used
(1, '2024-12-28', 'Watched Movie'),
(1, '2024-12-25', 'Watched Series'),
(1, '2024-12-20', 'Watched Movie'),
(1, '2024-12-15', 'Watched Series'),
 
-- Spotify (SubID 2) - Recently used
(2, '2024-12-29', 'Listened to Music'),
(2, '2024-12-27', 'Listened to Podcast'),
(2, '2024-12-22', 'Listened to Music'),
 
-- Adobe CC (SubID 3) - Recently used
(3, '2024-12-26', 'Used Photoshop'),
(3, '2024-12-20', 'Used Illustrator'),
(3, '2024-12-15', 'Used Premiere Pro'),
 
-- Netflix Standard (SubID 4) - Cancelled, old usage
(4, '2024-06-01', 'Watched Movie'),
(4, '2024-05-15', 'Watched Series'),
 
-- Microsoft 365 (SubID 5) - Paused, recent usage
(5, '2024-12-10', 'Used Word'),
(5, '2024-12-05', 'Used Excel'),
 
-- Jane's Netflix (SubID 6) - Very old usage (high risk)
(6, '2024-09-15', 'Watched Movie'),
(6, '2024-08-20', 'Watched Series'),
 
-- Amazon Prime (SubID 7) - Recent usage
(7, '2024-12-28', 'Watched Prime Video'),
(7, '2024-12-15', 'Free Shipping'),
 
-- Disney+ (SubID 8) - Recently used
(8, '2024-12-27', 'Watched Movie'),
(8, '2024-12-20', 'Watched Series'),
 
-- YouTube Premium (SubID 9) - Recently used
(9, '2024-12-29', 'Watched Video'),
(9, '2024-12-25', 'Watched Video'),
 
-- Alex's Netflix (SubID 10) - Old usage (high risk)
(10, '2024-10-01', 'Watched Movie'),
(10, '2024-09-15', 'Watched Series'),
 
-- Dropbox (SubID 11) - Recently used
(11, '2024-12-28', 'Uploaded Files'),
(11, '2024-12-20', 'Downloaded Files'),
 
-- GitHub Pro (SubID 12) - Recently used
(12, '2024-12-29', 'Pushed Code'),
(12, '2024-12-25', 'Created Repository'),
 
-- Notion (SubID 14) - Recently used
(14, '2024-12-27', 'Created Page'),
(14, '2024-12-20', 'Edited Notes');

-- Insert Alert Rules
INSERT INTO Alert_Rules (SubID, DaysBeforeRenewal, IsActive) VALUES
(1, 7, TRUE),
(2, 5, TRUE),
(3, 3, TRUE),
(5, 10, TRUE),
(6, 7, TRUE),
(7, 30, TRUE),
(8, 5, TRUE),
(9, 3, TRUE),
(10, 7, TRUE),
(11, 5, TRUE),
(12, 7, TRUE),
(13, 5, TRUE),
(14, 3, TRUE);
