-- Digital Subscription & Recurring Expense Optimizer
-- Database Schema - 3NF Normalized Structure

-- Drop tables if they exist (in reverse order of foreign key dependencies)


-- Users Table
CREATE TABLE Users (
    UserID INT AUTO_INCREMENT PRIMARY KEY,
    Name VARCHAR(100) NOT NULL,
    Email VARCHAR(150) UNIQUE NOT NULL,
    PasswordHash VARCHAR(255) NOT NULL,
    ProfilePhoto LONGTEXT NULL,
    WalletBalance DECIMAL(10,2) NOT NULL DEFAULT 0,
    CreatedAt DATETIME DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_email (Email)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Payment_Methods Table
CREATE TABLE Payment_Methods (
    MethodID INT AUTO_INCREMENT PRIMARY KEY,
    UserID INT NOT NULL,
    Provider VARCHAR(50),
    CardLast4 CHAR(4),
    ExpiryDate DATE,
    PaymentType ENUM('credit_card', 'debit_card', 'upi') DEFAULT 'credit_card',
    UPIID VARCHAR(100) NULL,
    CONSTRAINT fk_payment_user FOREIGN KEY (UserID)
        REFERENCES Users(UserID)
        ON DELETE CASCADE,
    CONSTRAINT chk_cardlast4 CHECK (CardLast4 REGEXP '^[0-9]{4}$' OR CardLast4 IS NULL)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Subscriptions Table
CREATE TABLE Subscriptions (
    SubID INT AUTO_INCREMENT PRIMARY KEY,
    UserID INT NOT NULL,
    MethodID INT,
    WebsiteURL VARCHAR(255) NULL,
    PlatformName VARCHAR(100) NOT NULL,
    PlanName VARCHAR(100),
    Cost DECIMAL(10,2) NOT NULL,
    BillingCycle ENUM('Monthly', 'Quarterly', 'Annual') NOT NULL,
    StartDate DATE NOT NULL,
    NextRenewalDate DATE NOT NULL,
    Status ENUM('Active', 'Paused', 'Cancelled') DEFAULT 'Active',
    AutoRenew BOOLEAN DEFAULT TRUE,
    CONSTRAINT fk_subscription_user FOREIGN KEY (UserID)
        REFERENCES Users(UserID)
        ON DELETE CASCADE,
    CONSTRAINT fk_subscription_payment FOREIGN KEY (MethodID)
        REFERENCES Payment_Methods(MethodID)
        ON DELETE SET NULL,
    CONSTRAINT chk_cost CHECK (Cost >= 0),
    INDEX idx_user_status (UserID, Status),
    INDEX idx_next_renewal (NextRenewalDate)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Usage_Logs Table
CREATE TABLE Usage_Logs (
    LogID INT AUTO_INCREMENT PRIMARY KEY,
    SubID INT NOT NULL,
    DateAccessed DATE NOT NULL,
    ActionType VARCHAR(50) NOT NULL,
    CONSTRAINT fk_usage_subscription FOREIGN KEY (SubID)
        REFERENCES Subscriptions(SubID)
        ON DELETE CASCADE,
    INDEX idx_sub_date (SubID, DateAccessed)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Alert_Rules Table
CREATE TABLE Alert_Rules (
    RuleID INT AUTO_INCREMENT PRIMARY KEY,
    SubID INT NOT NULL,
    DaysBeforeRenewal INT NOT NULL,
    IsActive BOOLEAN DEFAULT TRUE,
    CONSTRAINT fk_alert_subscription FOREIGN KEY (SubID)
        REFERENCES Subscriptions(SubID)
        ON DELETE CASCADE,
    CONSTRAINT chk_days_before CHECK (DaysBeforeRenewal BETWEEN 1 AND 30)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Transactions Table (wallet)
CREATE TABLE Transactions (
    TransactionID INT AUTO_INCREMENT PRIMARY KEY,
    UserID INT NOT NULL,
    Type ENUM('credit', 'debit') NOT NULL,
    Amount DECIMAL(10,2) NOT NULL,
    Description VARCHAR(255),
    SubID INT NULL,
    CreatedAt DATETIME DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_transaction_user FOREIGN KEY (UserID)
        REFERENCES Users(UserID)
        ON DELETE CASCADE,
    CONSTRAINT fk_transaction_subscription FOREIGN KEY (SubID)
        REFERENCES Subscriptions(SubID)
        ON DELETE SET NULL,
    INDEX idx_user_date (UserID, CreatedAt)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
