# Digital Subscription & Recurring Expense Optimizer

A full-stack academic web application for tracking recurring software and service payments, viewing renewal dates, logging usage, and identifying potentially underutilized subscriptions.

## Current Tech Stack

- **Frontend:** Plain HTML, CSS, and JavaScript in `frontend/`
- **Styling:** Tailwind CSS loaded through the CDN
- **Backend:** Node.js with Express in `backend/`
- **Database:** MySQL
- **Authentication:** JWT and bcrypt password hashing

There is no React frontend or frontend build step. The empty/unused `client/` directory should be ignored.

## Features

- User registration and login
- JWT-protected API routes
- Payment method management
- Subscription creation, editing, and deletion
- Automatic next-renewal date calculation
- Usage logging
- Renewal alert rules
- Dashboard and waste-expense analytics
- Normalized MySQL schema with foreign keys and transactions

## Prerequisites

- Node.js 18 or higher
- npm
- MySQL 5.7 or higher, preferably MySQL 8
- Internet access for the Tailwind CSS CDN

## Project Structure

```text
Project/
├── backend/
│   ├── config/
│   │   └── database.js          # MySQL connection pool
│   ├── controllers/             # API business logic
│   ├── middleware/
│   │   └── auth.js              # JWT authentication middleware
│   ├── routes/                  # Express route definitions
│   ├── server.js                # Express server and static frontend
│   └── package.json
├── database/
│   ├── schema.sql               # MySQL tables and constraints
│   └── seed.sql                 # Optional sample data
├── frontend/
│   ├── css/
│   │   └── styles.css
│   ├── js/
│   │   └── app.js               # Shared frontend API/UI logic
│   └── *.html                   # Application pages
├── .env.example
└── README.md
```

## Setup

### 1. Create the MySQL database

Open the MySQL command line or MySQL Workbench and run:

```sql
CREATE DATABASE IF NOT EXISTS subscription_optimizer;
```

If the `mysql` command is not on your PATH, use the full path to `mysql.exe` or MySQL Workbench.

### 2. Import the schema

From the project root in Command Prompt:

```bat
mysql -u root -p subscription_optimizer < database\schema.sql
```

On Windows, if `mysql` is not on PATH, use the installed MySQL client path, for example:

```bat
"C:\Program Files\MySQL\MySQL Server 8.0\bin\mysql.exe" -u root -p subscription_optimizer < "database\schema.sql"
```

You can also open `database\schema.sql` in MySQL Workbench and execute it while `subscription_optimizer` is selected.

### 3. Optional sample data

```bat
mysql -u root -p subscription_optimizer < database\seed.sql
```

The seed file contains placeholder password hashes, so seeded users may not be able to log in. For normal use, import only the schema and register a user through the application.

### 4. Configure environment variables

The backend must run from the `backend` directory, so its `.env` file must also be inside `backend`.

From the project root in Command Prompt:

```bat
copy .env.example backend\.env
```

Open `backend\.env` and set your actual values:

```env
DB_HOST=localhost
DB_USER=root
DB_PASSWORD=your_mysql_password
DB_NAME=subscription_optimizer
DB_PORT=3306

JWT_SECRET=change_this_to_a_long_random_secret

PORT=5000
NODE_ENV=development
```

Do not commit `backend\.env` or any real `.env` file.

### 5. Install backend dependencies

```bat
cd backend
npm install
```

Only the backend needs `npm install`. There is no frontend dependency installation step.

## Run the Application

From the `backend` directory:

```bat
cd backend
npm run dev
```

For normal mode without auto-restart:

```bat
npm start
```

Expected output:

```text
Server running on port 5000
```

Open the application at:

```text
http://localhost:5000/login.html
```

`http://localhost:5000/` returns JSON API information; it does not display the UI because there is no `index.html`.

Stop the server with `Ctrl+C`.

## Using the Application

1. Open `http://localhost:5000/register.html` or use the register link.
2. Create an account.
3. Add a payment method from `payment-methods.html`.
4. Add subscriptions from `subscription-form.html`.
5. View the dashboard, subscription list, usage logs, and analytics pages.

## API Endpoints

All routes below require a JWT token unless marked as public.

### Authentication

- `POST /api/auth/register` — public
- `POST /api/auth/login` — public
- `GET /api/auth/profile` — protected

### Payment Methods

- `GET /api/payments`
- `POST /api/payments`
- `PUT /api/payments/:methodId`
- `DELETE /api/payments/:methodId`

### Subscriptions

- `GET /api/subscriptions`
- `GET /api/subscriptions/:subId`
- `POST /api/subscriptions`
- `PUT /api/subscriptions/:subId`
- `DELETE /api/subscriptions/:subId`

### Usage Logs

- `GET /api/usage/:subId`
- `POST /api/usage`
- `DELETE /api/usage/:logId`

### Alert Rules

- `GET /api/alerts/:subId`
- `POST /api/alerts`
- `PUT /api/alerts/:ruleId`
- `DELETE /api/alerts/:ruleId`

### Analytics

- `GET /api/analytics/waste-report`
- `GET /api/analytics/dashboard`

## Troubleshooting

### MySQL connection failed

- Confirm the MySQL service is running.
- Confirm the `subscription_optimizer` database exists.
- Confirm `DB_HOST`, `DB_USER`, `DB_PASSWORD`, and `DB_NAME` in `backend\.env`.
- Import `database\schema.sql` if tables are missing.

### `.env` values are ignored

The server must be started from `backend` using `npm start` or `npm run dev`, and the environment file must be `backend\.env`.

### Port 5000 is already in use

Change `PORT` in `backend\.env`, for example:

```env
PORT=5001
```

Then open `http://localhost:5001/login.html`.

### Styling does not load

The HTML pages load Tailwind CSS from `https://cdn.tailwindcss.com`. An internet connection is required unless the styling is changed to use local CSS.

### Seed users cannot log in

`database\seed.sql` uses placeholder bcrypt hashes. Register a new user through the UI instead.

### Module not found

Run:

```bat
cd backend
npm install
```

## License

This is a DBMS academic mini-project.
